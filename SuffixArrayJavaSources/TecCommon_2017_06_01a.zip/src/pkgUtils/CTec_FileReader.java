package pkgUtils;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.Arrays;

public class CTec_FileReader {
	//
	//	File read handlers
	//
	public static boolean m_bEof = false;
	private final static int iC_BUFFER_SIZE = 16*1024;
	private final static int iC_BOM_0 = -1, iC_BOM_1 = -2;

	private static byte[] m_abBuffer = null;
	private static int m_iBuffPos, m_iBuffLength, m_iCharSize;

	private static long m_i64FilePos;
	private static String m_sLineStart;
	private static boolean m_bNeedBuffer, m_bInit, m_bUnicode;
	
	//
	//	class CTecJ_FileRef: File reference (filename, line, position)
	//
	public static class CTec_FileRef {
		public String m_sLine;
		public long m_i64Pos;
		
		public CTec_FileRef( String _sLine, long _i64Pos ){
			this.m_sLine = _sLine;
			this.m_i64Pos = _i64Pos;
		}
	}

	//
	//	i_ReadBuffer: Read one more buffer from file
	//
	private static int i_ReadBuffer( FileInputStream _oInputStream ){
		int iReadBytes = 0;
		
		// Check EOF
		try {
			if (_oInputStream.getChannel().position() >= _oInputStream.getChannel().size()){
				return -1;
			}
			iReadBytes = _oInputStream.read(m_abBuffer);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return iReadBytes;
	}
	
	//
	//	Huge files - read by buffers, and split into lines on-the-fly
	//
	static public CTec_FileRef o_ReadLine( FileInputStream _oInputStream ) {
		CTec_FileRef oLineRef;
		byte[] abSlice;
		int iPos, iEnd = 0;
		boolean bEndOfBuff;
		String sSlice = "";
		oLineRef = new CTec_FileRef("", 0);
		
		if ( m_abBuffer == null ) {
			m_abBuffer = new byte[iC_BUFFER_SIZE];
			m_iBuffPos = 0;
			m_iBuffLength = 0;
			m_iCharSize = 0;
			m_i64FilePos = 0;
			m_sLineStart = "";
			m_bNeedBuffer = true;
			m_bInit = false;
			m_bUnicode = false;
		}
		

		while(true){
			if ( m_bNeedBuffer ){
				m_bNeedBuffer = false;
				m_i64FilePos += m_iBuffLength;
				m_iBuffLength = i_ReadBuffer(_oInputStream);
				if (m_iBuffLength < 0) {
					if ( m_sLineStart.isEmpty() ) {
						m_bEof = true;
					}
					oLineRef.m_sLine = m_sLineStart;
					oLineRef.m_i64Pos = m_i64FilePos;
					return oLineRef;
				}
				m_iBuffPos = 0;
				
				// Detect BOM
				if (!m_bInit){
					m_bInit = true;
					if (m_iBuffLength < 2){
						m_bUnicode = false;
						m_iCharSize = 1;
					}
					else{
						m_bUnicode = (m_abBuffer[0] == iC_BOM_0) && (m_abBuffer[1] == iC_BOM_1);
						if (m_bUnicode){
							m_iCharSize = 2;
							m_iBuffPos = 2;
						}
						else
							m_iCharSize = 1;
					}
				}
			}
			
			iPos = m_iBuffPos;
			bEndOfBuff = false;
			while ( iPos < m_iBuffLength ){
				if (m_abBuffer[iPos] == '\n'){
					iEnd = iPos;
					iPos += m_iCharSize;
					if ( iPos < m_iBuffLength ) {
						if (m_abBuffer[iPos] == '\r'){
							iPos += m_iCharSize;
						}
					}
					bEndOfBuff = true;
				}
				if ( ( iPos < m_iBuffLength ) && ( m_abBuffer[iPos] == '\r') ) {
					iEnd = iPos;
					iPos += m_iCharSize;
					if ( iPos < m_iBuffLength ) {
						if (m_abBuffer[iPos] == '\n'){
							iPos += m_iCharSize;
						}
					}
					bEndOfBuff = true;
				}
				if ( bEndOfBuff ) {
					if ( iEnd >= m_iBuffPos ) { 
						abSlice = Arrays.copyOfRange(m_abBuffer, m_iBuffPos, iEnd );
						try {
							if (!m_bUnicode)
								sSlice = new String(abSlice, "UTF-8");
							else
								sSlice = new String(abSlice, "UTF-16LE");
						} catch (UnsupportedEncodingException e) {
							e.printStackTrace();
						}
						oLineRef.m_sLine = m_sLineStart + sSlice;
						oLineRef.m_i64Pos = m_i64FilePos + m_iBuffPos;

						m_sLineStart = "";
						m_iBuffPos = iPos;
						return oLineRef;
					}
					bEndOfBuff = false;
					continue;
				}
				iPos += m_iCharSize;
			}
			if (m_iBuffPos < m_iBuffLength){
				abSlice = Arrays.copyOfRange(m_abBuffer, m_iBuffPos, m_iBuffLength);
				try {
					if (!m_bUnicode)
						sSlice = new String(abSlice, "UTF-8");
					else
						sSlice = new String(abSlice, "UTF-16LE");
				} catch (UnsupportedEncodingException e) {
					e.printStackTrace();
				}
				m_sLineStart = sSlice;
			}
			else{
				m_sLineStart = "";
			}
			m_bNeedBuffer = true;
		}
	}
}
