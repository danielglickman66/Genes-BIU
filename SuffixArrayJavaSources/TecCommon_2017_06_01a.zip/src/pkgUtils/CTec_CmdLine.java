package pkgUtils;

import java.util.ArrayList;

import pkgUtils.CTec_Utils;

//
//	Command-line parser
//
public class CTec_CmdLine {
	private static final int iC_SWITCH_LEN = 10;
	private static final char cC_Switch = '-', cC_Negate = '-'; 
	
	//
	//	Holds a single user-defined option
	//
	private class ClOption{
		int m_iOrderIx;
		String m_sOrgParam, m_sOptionVal, m_sOrgVal, m_sHelp;
		boolean m_bFree, m_bUser, m_bNegate;
		
		public ClOption(){
			this.m_iOrderIx = 0;
			this.m_sOrgParam = "";
			this.m_sOptionVal = "";
			this.m_sOrgVal = "";
			this.m_sHelp = "";
			this.m_bFree = false;
			this.m_bUser = false;
			this.m_bNegate = false;
		}
	}
	
	//
	//	Holds a command-line parameter name/value/...
	//
	private class ClParam{
		String m_sArg;
		ClOption m_oClOpt;
		
		public ClParam(){
			this.m_sArg = "";
			this.m_oClOpt = null;
		}
	}
	
	//
	//	Holds ALL command-line parameters
	//
	ArrayList<ClParam> m_aloParams;

	//
	//	Record parsing/undefined/etc. errors
	//
	ArrayList<String> m_alsErrors;

	int m_iLastIx;
	boolean m_bHelp;
	
	//
	//	CTecJ_CmdLine constructor
	//
	public CTec_CmdLine(){
		m_aloParams = new ArrayList<ClParam>();
		m_alsErrors = new ArrayList<String>();
		m_iLastIx = 0;
		m_bHelp = false;
	}
	
	//
	//	i_findOption: look for a user-defined option 
	//
	private int i_findOption(String _sSw, String _sHelp, int _iMinCh){
		ClOption oClOpt = null;
		ClParam oClParam = null;
		int iList, iRes = -1, iRealMinCh;
		String sOpt, sSw = _sSw.toLowerCase();
		
		if (_iMinCh >= 1)
			iRealMinCh = _iMinCh+1;
		else
			iRealMinCh = _iMinCh;
		
		if ( (iRealMinCh >= 0) && (iRealMinCh < sSw.length()) ){
			for (iList=0; iList<m_aloParams.size(); iList++){
				oClParam = m_aloParams.get(iList);
				sOpt = oClParam.m_sArg;
				oClOpt = oClParam.m_oClOpt;
				
				if (oClOpt.m_bFree)
					continue;
				
				if (sOpt.substring(0, iRealMinCh).equals(sSw.substring(0, iRealMinCh))){
					iRes = iList;
					oClParam.m_sArg = sSw;
					m_aloParams.set(iList, oClParam);
					break;
				}
				else{	
					iList++;
				}
			}
		}
		else{ 
			for (iList=0; iList<m_aloParams.size(); iList++){
				oClParam = m_aloParams.get(iList);
				if (oClParam.m_sArg.equals(sSw)){
					iRes = iList;
					break;
				}
			}
		}
		
		if (iRes < 0){
			oClOpt =  new ClOption();
			oClParam =  new ClParam();
			oClParam.m_oClOpt = oClOpt;
			oClParam.m_sArg = sSw;
			m_aloParams.add(oClParam);
			iRes = m_aloParams.size()-1;
		}
		
		oClParam = m_aloParams.get(iRes);
		oClParam.m_oClOpt.m_sHelp = _sHelp;
		oClParam.m_oClOpt.m_iOrderIx = m_iLastIx+1;
		m_iLastIx++;
		
		return iRes;
	}
	
	//
	//	writeHelpLine: Write one help line 
	//
	private void writeHelpLine(String _sOption, String _sUse){
		System.out.println(CTec_Utils.s_PadRight(_sOption, iC_SWITCH_LEN)+_sUse);
	}
	
	//
	//	init: parse actual data 
	//
	public boolean init(int _iNumOfFree, int _iNumOfMust, String[] _asCmdLine){
		int iNumOfFree = 0, iImport = 0, iLen;
		String sThisParam, sVal, sNextParam;
		boolean bSw, bNoValue;
		ClOption oClOpt;
		ClParam oClParam;
		
		while(iImport < _asCmdLine.length){
			oClOpt = new ClOption();
			oClOpt.m_bUser = true;
			oClOpt.m_sOrgParam = _asCmdLine[iImport];
			sVal = oClOpt.m_sOrgParam.toLowerCase();
			bSw = sVal.charAt(0) == cC_Switch;
			if ( bSw ) {
				iLen = sVal.length();
				if ( iLen > 2 ) {
					if ( sVal.charAt( iLen - 1 ) == cC_Negate ) {
						sVal = sVal.substring( 0, iLen - 1 );
						oClOpt.m_bNegate = true; 
					}
				}
				sThisParam = "-" + sVal.substring(1);
			}
			else {
				sThisParam = oClOpt.m_sOrgParam;
			}
			
			if (bSw){
				if (sThisParam.length() < 2){
					m_alsErrors.add("switch without option");
					iImport++;
					continue;
				}
				if (iImport < _asCmdLine.length-1){
					sNextParam = _asCmdLine[iImport+1];
				}
				else{
					sNextParam = "--";
				}
				if ( sNextParam.charAt(0) != cC_Switch ){
					bNoValue = false;
					oClOpt.m_sOrgVal = sNextParam;
					oClOpt.m_sOptionVal = sNextParam.toUpperCase();
				}
				else
					bNoValue = true;
				if (sThisParam.equals("-?")){
					m_bHelp = true;
				}
				else{
					oClParam = new ClParam();
					oClParam.m_oClOpt = oClOpt;
					oClParam.m_sArg = sThisParam;
					m_aloParams.add(oClParam);
					if (!bNoValue)
						iImport++;
				}
			}
			else{
				oClOpt.m_bFree = true;
				oClOpt.m_iOrderIx = m_iLastIx+1;
				m_iLastIx++;
				oClParam = new ClParam();
				oClParam.m_oClOpt = oClOpt;
				oClParam.m_sArg = sThisParam;
				m_aloParams.add(oClParam);
				iNumOfFree++;
				if (iNumOfFree > _iNumOfFree){
					m_alsErrors.add("extra parameter '"+sThisParam+"'");
					iImport++;
					continue;
				}
				
			}
			iImport++;
		}
		if (iNumOfFree < _iNumOfMust){
			if (_iNumOfMust - iNumOfFree == 1){
				m_alsErrors.add("missing free parameter");
			}
			else{
				m_alsErrors.add("missing free parameters");
			}
		}
		return (m_alsErrors.size() == 0);
	}
	
	//
	//	s_OptFree 
	//
	public String s_OptFree(int _iIx, boolean _bCase){
		ClOption oClOpt = null;
		ClParam oClParam = null;
		int iCounter = 0;
		String sOpt;
		
		for (int iList=0; iList<m_aloParams.size(); iList++){
			oClParam = m_aloParams.get(iList);
			sOpt = oClParam.m_sArg;
			oClOpt = oClParam.m_oClOpt;
			
			if (oClOpt.m_bFree){
				iCounter++;
				if (iCounter == _iIx){
					if (!_bCase){
						return sOpt;
					}
					else{
						return oClOpt.m_sOrgParam;
					}
				}
			}
		}
		
		return "";
	}
	
	//
	//	s_OptFree  
	//
	public String s_OptFree(int _iIx){
		return s_OptFree(_iIx, false);
	}
	
	//
	//	s_OptFreeAsCaseString  
	//
	public String s_OptFreeAsCaseString(int _iIx){
		return s_OptFree(_iIx, true);
	}
	
	//
	//	b_OptAppears  
	//
	public boolean b_OptAppears(String _sSw, String _sHelp, int _iMinCh, boolean _bDefault){
		int iIx = i_findOption( _sSw, _sHelp, _iMinCh );
		ClParam oClParam;
		
		if ( iIx >= 0 ){
			oClParam = m_aloParams.get(iIx);
			if ( oClParam.m_oClOpt.m_bNegate )
				return !oClParam.m_oClOpt.m_bUser;
			return oClParam.m_oClOpt.m_bUser;
		}
		else
			return false;
	}
	
	//
	//	s_OptAsString  
	//
	public String s_OptAsString(String _sSw, String _sHelp, int _iMinCh){
		int iIx = i_findOption(_sSw, _sHelp, _iMinCh);
		ClParam oClParam;
		
		if (iIx >= 0){
			oClParam = m_aloParams.get(iIx);
			if (oClParam.m_oClOpt.m_bUser)
				return oClParam.m_oClOpt.m_sOptionVal;
		}
		return "";
	}
	
	//
	//	s_OptAsCaseString  
	//
	public String s_OptAsCaseString(String _sSw, String _sHelp, int _iMinCh){
		int iIx = i_findOption(_sSw, _sHelp, _iMinCh);
		ClParam oClParam;
		
		if (iIx >= 0){
			oClParam = m_aloParams.get(iIx);
			if (oClParam.m_oClOpt.m_bUser)
				return oClParam.m_oClOpt.m_sOrgVal;
		}
		return "";
	}
	
	//
	//	s_OptExistsAsString  
	//
	public String s_OptExistsAsString(String _sSw, String _sHelp, int _iMinCh, String _sDefault){
		int iIx = i_findOption(_sSw, _sHelp, _iMinCh);
		ClParam oClParam;
		
		if (iIx >= 0){
			oClParam = m_aloParams.get(iIx);
			if (oClParam.m_oClOpt.m_bUser)
				return oClParam.m_oClOpt.m_sOptionVal;
		}
		return _sDefault;
	}
	
	//
	//	s_OptAsFileName  
	//
	public String s_OptAsFileName(String _sSw, String _sHelp, String _sExt, int _iMinCh){
		String sRes = s_OptAsCaseString(_sSw, _sHelp, _iMinCh);
		int iPos;
		
		if (sRes.length() > 0){
			iPos = sRes.lastIndexOf('.');
			if (iPos < 0)
				return sRes + "." + _sExt;
		}
		return sRes;
	}
	
	//
	//	i_OptAsInt  
	//
	public int i_OptAsInt(String _sSw, String _sHelp, int _iMinCh, int _iDefault){
		int iIx = i_findOption(_sSw, _sHelp, _iMinCh), iRes;
		ClParam oClParam;
		
		if (iIx >= 0){
			oClParam = m_aloParams.get(iIx);
			if (oClParam.m_oClOpt.m_bUser){
				iRes = CTec_Utils.i_safeStringToInt(oClParam.m_oClOpt.m_sOptionVal);
				if (CTec_Utils.m_bError)
					return _iDefault;
				return iRes;
			}
		}
		return _iDefault;
	}
	
	//
	//	i_OptAsBounded  
	//
	public int i_OptAsBounded(String _sSw, String _sHelp, int _iMinCh, int _iMin, int _iDefault, int _iMax){
		int iIx = i_findOption(_sSw, _sHelp, _iMinCh), iRes;
		ClParam oClParam;
		
		if (iIx >= 0){
			oClParam = m_aloParams.get(iIx);
			if (oClParam.m_oClOpt.m_bUser){
				iRes = CTec_Utils.i_safeStringToInt(oClParam.m_oClOpt.m_sOptionVal);
				if (CTec_Utils.m_bError)
					return _iDefault;
				if ((iRes < _iMin) || (iRes > _iMax)){
					m_alsErrors.add("value out of range '"+oClParam.m_oClOpt.m_sOptionVal+"'");
					return _iDefault;
				}
				return iRes;
			}
		}
		return _iDefault;
	}
	
	//
	//	i_OptAsDouble  
	//
	public double i_OptAsDouble( String _sSw, String _sHelp, int _iMinCh, double _dDefault ) {
		int iIx = i_findOption(_sSw, _sHelp, _iMinCh);
		double dRes;
		ClParam oClParam;
		
		if ( iIx >= 0 ) {
			oClParam = m_aloParams.get(iIx);
			if (oClParam.m_oClOpt.m_bUser){
				dRes = CTec_Utils.d_safeStringToDouble( oClParam.m_oClOpt.m_sOptionVal );
				if (CTec_Utils.m_bError)
					return _dDefault;
				return dRes;
			}
		}
		return _dDefault;
	}
	
	//
	//	showHelp  
	//
	public void showHelp( String _sName, String _sVersion, String _sProgrammer, String _sUsage ){
		ClOption oClOpt; 
		String sMsg = "", sOpt;
		
		if (m_aloParams.size() > 0)
			sMsg =  " [parameters]";
		System.out.println( _sName + " " + _sVersion + " [by: " + _sProgrammer +
			"] usage: java -jar " + _sName +_sVersion + ".jar " + _sUsage + sMsg );
		
		sMsg = "";
		writeHelpLine("parameter", "use");
		writeHelpLine("---------", "---");
		for (int i=0; i<m_aloParams.size() ; i++){
			oClOpt = m_aloParams.get(i).m_oClOpt;
			sOpt = m_aloParams.get(i).m_sArg.toLowerCase();
			if (oClOpt.m_bFree)
				continue;
			writeHelpLine(sOpt, m_aloParams.get(i).m_oClOpt.m_sHelp);
		}
	}
	
	//
	//	b_Done  
	//
	public boolean b_Done(String _sName, String _sVersion, String _sProgrammer, String _sUsage){
		ClOption oClOpt;
		ClParam oClParam;
		int iList;
		String sOpt;
		boolean bStop = false;
		
		for (iList=0; iList<m_aloParams.size(); iList++){
			oClParam = m_aloParams.get(iList);
			sOpt = oClParam.m_sArg;
			oClOpt = oClParam.m_oClOpt;
			if ((oClOpt.m_iOrderIx == 0) && (!oClOpt.m_bFree) && !(sOpt.substring(1, 2).equals("_"))){
				m_alsErrors.add("extra parameter '"+sOpt+"'");
			}
		}
		bStop = (m_alsErrors.size() > 0) || (m_bHelp);
		if (bStop){
			showHelp( _sName, _sVersion, _sProgrammer, _sUsage );
		}
		return !bStop;
	}
}
