package control;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;

import pkgUtils.CTec_Utils;
import pkgUtils.CTec_CmdLine;
import pkgSAModel.SAFileSplit;
import pkgSAModel.SuffixArray;


/*
 * java -jar G:\...\FolderOfProjectWithJar\SABuilder.jar input_folder output_folder [options]
 * java -jar G:\...\FolderOfProjectWithJar\SAAnaliser.jar work_folder output_folder [options]
 */

public class Control {
	final static String sC_PROG_NAME = "SuffixArrayAnalyzer", sC_PROG_VERS = "1.8", sC_PROGRAMMER = "TeC";

	final static String sC_EXT_TEXT = ".txt";
	static final String sC_TOPSCORES_PX = "top_";
	static final String sC_TRAIN_COUNT_PX = "train_count_";
	static final String sC_TRAIN_SCORE_PX = "train_score_";
	
	public enum E_SortCode {
		eSTRING, eCOUNT, eSCORE;
	}
	
	enum E_ComputationType {
		eAverage, eStdDev, eScore;
	}
	
	//
	//	User' options storage
	//
	static CTec_CmdLine m_oCmdLine;
	static int m_iTop, m_iSort, m_iMaxLines, m_iMinCount;
	static double m_dMinScore;

	static String m_sWorkFolder, m_sOutputFolder, m_sTestString;
	static boolean m_bNormalize;
	static E_SortCode m_eSortCode;
	
	//
	//	Work variables
	//
	static int m_iFreeParamsCount, m_iMustParamsCount, m_iSplitCount = 0;
	static String m_sOutFName, m_sOutFullFName, m_sTrainCountFName, m_sTrainScoreFName;
	static boolean m_bUserFName = false;

	//	Debug helpers
	static boolean m_bDebug, m_bProgress;
	static long m_i64TotSaveTime = 0, m_i64TotBuffersSize = 0;
	
	//
	//	Control: CONSTRUCTOR
	//
	public Control(){
		m_oCmdLine =  new CTec_CmdLine();
	}

	//
	//	init: Set parameters for command-line parsing and parse it
	//
	public boolean init( String[] _CmdLineArgs ) {
		//
		//	We require only Input folder to be passed. All other have their default values.
		//
		m_iFreeParamsCount = 2;
		m_iMustParamsCount = 1;
		
		if (!parseCmdLine( _CmdLineArgs )){
			return false;
		}
		return true;
	}
	
	//
	//	parseCmdLine: Define user parameters (with defaults) and check command-line for any selected value
	//
	public static boolean parseCmdLine(String[] _asArgs){
		boolean bDone;
		
		m_oCmdLine.init( m_iFreeParamsCount, m_iMustParamsCount, _asArgs);
		
		//	Input is from Builder "Work" folder
		m_sWorkFolder = m_oCmdLine.s_OptFree(1);
		m_sOutputFolder = m_oCmdLine.s_OptFree(2);
		m_sOutFName = m_oCmdLine.s_OptAsCaseString("-output", "output filename", -1);

		m_iTop = m_oCmdLine.i_OptAsInt("-top", "set number of top entries in results table", -1, 50);
		m_iSort = m_oCmdLine.i_OptAsInt("-sort", "sorting code(=1:score, 2:count)", -1, 1);
		
		m_bNormalize = m_oCmdLine.b_OptAppears("-norm", "normalize STD.DEV", -1, false);

		//	Debug control and print parameters
		m_iMaxLines = m_oCmdLine.i_OptAsInt("-max.lines", "maximum number of lines in debug file(s)", -1, 10000 );
		m_iMinCount = m_oCmdLine.i_OptAsInt("-min.count", "values above this will be print in " + sC_TRAIN_COUNT_PX + sC_EXT_TEXT, -1, Integer.MAX_VALUE );
		m_dMinScore = m_oCmdLine.i_OptAsDouble("-min.score", "values above this will be print in " + sC_TRAIN_SCORE_PX + sC_EXT_TEXT, -1, Integer.MAX_VALUE );
		m_sTestString = m_oCmdLine.s_OptAsCaseString("-test", "A string whose computations will be traced for debugging", -1);
		m_bDebug = m_oCmdLine.b_OptAppears("-debug", "debug mode", -1, false);
		m_bProgress = m_oCmdLine.b_OptAppears("-progress", "progress feedback", -1, false);
		
		bDone = m_oCmdLine.b_Done(sC_PROG_NAME, sC_PROG_VERS, sC_PROGRAMMER, "input-folder [output-folder]");
		
		//	Note: Should never occur, because cmd-line checks minimum parameters
		if ( m_sWorkFolder.isEmpty() ) {
			System.out.println( "*** ERROR: Missing work folder" );
			return false;
		}
		
		//
		//	Validate work folder
		//
		if ( !Files.exists(Paths.get(m_sWorkFolder) ) ) {
			System.out.println( "*** ERROR: Invalid work folder '" + m_sWorkFolder + "'" );
			return false;
		}

		if (m_sOutputFolder.isEmpty()){
			m_sOutputFolder = CTec_Utils.s_filePathOf( CTec_Utils.s_filePathOf( m_sWorkFolder ) ) + CTec_Utils.getPathSeparator() + "Output";
		}
		if (!CTec_Utils.b_MakeFolder(m_sOutputFolder)){
			System.out.println( "*** ERROR: cannot create folder '" + m_sOutputFolder + "'" );
			return false;
		}
		if ( m_iTop <= 0 ) {
			System.out.println( "*** ERROR: ivalid TOP=" + m_iTop );
			return false;
		}
		
		m_eSortCode = e_sortCode( m_iSort ); 
		
		return bDone;
	}
	
	//
	//	EchoParameters: show selections (and defaults) on screen (and LOG)
	//
	static void EchoParameters() {
		String sPrompt;
		CTec_Utils.debugLogAndPrintLn( "Running on work folder '" + m_sWorkFolder + "'" );
		sPrompt = "for parameters: top=" + m_iTop +
				" sort=" + m_iSort + " (" + s_sortCode(m_iSort) + ")";

		if ( !m_sOutFName.isEmpty() )
			sPrompt = sPrompt + " output=" + m_sOutFName;
		if ( m_bNormalize )
			sPrompt = sPrompt + " normalized";
		if ( !m_sTestString.isEmpty() )
			sPrompt = sPrompt + " test=" + m_sTestString;
		if ( m_bDebug )
			sPrompt = sPrompt + " mode=debug";
		CTec_Utils.debugLogAndPrintLn( sPrompt );
		CTec_Utils.debugLogAndPrintLn( String.format("%064d", 0).replace( "0", "-" ) );
	}

	//
	//	LogStats: Log some summaries stats for analysis
	//
	static void LogStats( SuffixArray _oArray ) {
		if (!m_bDebug)
			return;

		CTec_Utils.debugLogLn( String.format( "Split max.infixes =%,15d", _oArray.m_i64SplitMaxInfixCount ) );
		CTec_Utils.debugLogLn( String.format( "total infixes     =%,15d", _oArray.m_i64TotInfixCount ) );
	}
	
	//
	//	e_sortCode: translate int parameter for Sort code into enumeration
	//
	public static E_SortCode e_sortCode( int _iCode ) {
		switch(_iCode){
		case 0:
			return E_SortCode.eSTRING;
		case 1:
			return E_SortCode.eSCORE;
		default: return E_SortCode.eCOUNT;
		}
	}
	
	//
	//	s_sortCode: translate int parameter for Sort code into name
	//
	public static String s_sortCode(int _iCode){
		switch(_iCode){
		case 0:
			return E_SortCode.eSTRING.toString().substring(1);
		case 1:
			return E_SortCode.eSCORE.toString().substring(1);
		default: return E_SortCode.eCOUNT.toString().substring(1);
		}
	}
	
	//
	//	SACompute: Compute one of Average, STD.DEV, Score
	//
	public static void SACompute( E_ComputationType _eComputationType, SuffixArray _oArray ) {
		
		String sComputeType, sSplitFormatted, sProgressHeader;
		long i64TimeSt;
		char cSep = ( m_bProgress ) ? '-' : ' ';
		
		switch ( _eComputationType ) {
			case eAverage: {
				sComputeType = "AVERAGE";
				break;
			}
			case eStdDev: {
				sComputeType = "STD.DEV";
				break;
			}
			default: {
				sComputeType = "SCORE";
				break;
			}
		}
	
		//
		//	Compute AVERAGE
		//
		if ( m_bProgress ) 
			CTec_Utils.debugLogAndPrintLn( "... " + sComputeType + ": computing" );
		i64TimeSt = System.currentTimeMillis();
		_oArray.resetStats();

		for ( int iSplit = 1; iSplit <= m_iSplitCount; iSplit++ ) {
			sSplitFormatted = String.format( "%2d", iSplit ) + " of " + String.format( "%2d", m_iSplitCount );
			sProgressHeader = " " + sComputeType + ": Suffix Array[" + sSplitFormatted + "]= ";

			//
			//	Clean previous Split data
			//
			_oArray.clearSplit();

			if ( m_bProgress )  
				CTec_Utils.debugLogAndPrintLn( sComputeType + ", Split: " + sSplitFormatted );
			
			//
			//	Load saved Suffix Array
			//
			if ( _oArray.b_LoadSuffixArray( iSplit ) ){
				CTec_Utils.debugLogAndPrintLn( String.format( ">>>" + sProgressHeader + "%s",
						CTec_Utils.s_StampTime( "loaded in", false ) ) );
			}
			else {
				CTec_Utils.debugLogAndPrintLn( _oArray.s_Error() );
				return;
			}

			switch ( _eComputationType ) {
				case eAverage: {
					_oArray.scanTotalAndDiff( iSplit );
					break;
				}
				case eStdDev: {
					_oArray.scanStdDev( iSplit );
					break;
				}
				default: {
					_oArray.scanStdScore( iSplit );
					break;
				}
			}
	
			CTec_Utils.debugLogAndPrintLn( String.format( "... " + sComputeType + "[" + String.format( "%2d", iSplit ) + "]: " + "%s, %s",
				CTec_Utils.s_StampTime( "computed in", false ), CTec_Utils.s_StampElapsed( "Elapsed for " + sComputeType, i64TimeSt ) ), cSep );
		}

		switch ( _eComputationType ) {
			case eAverage: {
				_oArray.calcAverage();
				break;
			}
			case eStdDev: {
				_oArray.calcStdDev();
				break;
			}
			default: {
				_oArray.DbgEpilogue();
				printTop( _oArray );
				break;
			}
		}
		
		CTec_Utils.debugLogAndPrintLn( String.format( ">>> " + sComputeType + "     : %s %s",
			CTec_Utils.s_StampElapsed( "computed in", i64TimeSt ), CTec_Utils.s_StampTime( "total elapsed", true ) ), '-' );
	}
	
	//
	//	printTop 
	//
	public static void printTop( SuffixArray _oArray ){
		
		PrintWriter oWriter;
		ArrayList<SuffixArray.Infix> alTopToPrint = null;
		String sTopInfix;
		SuffixArray.Infix oInfix;
		byte [] caInfix = new byte [0];
		
		try{
			oWriter = new PrintWriter( m_sOutFullFName, "UTF-16LE" );
		} catch (IOException e) {
			System.out.println( "unable to open file '" + m_sOutFullFName + "'" );
			return;
		}
		
		switch(m_eSortCode){
		case eCOUNT:
			alTopToPrint = _oArray.ol_TopCount();
			break;
		case eSCORE:
			alTopToPrint = _oArray.ol_TopScore();
			break;
		default:
			break;
		}
		
		if ( alTopToPrint != null ) {
			//
			//	Print largest numbers at top
			//
			for ( int k = alTopToPrint.size()-1; k >= 0; k-- ) {
				oInfix = alTopToPrint.get(k);
				caInfix = oInfix.m_caInfix;
				sTopInfix = new String(caInfix);

				oWriter.write( String.format( SuffixArray.sC_SA_DATA_FORMAT,
					oInfix.m_iCount, oInfix.m_dStdScore, CTec_Utils.s_PadRight( sTopInfix, 64) ) );
			}
		}
		
		oWriter.close();
	}
	
	//
	//	i_EnumerateSplits: enumerate .saf files
	//
	static int i_EnumerateSplits( SuffixArray _oArray ) {
		int iFileCount = 0;
		File oFolder = new File( m_sWorkFolder );
		File[] sArrFiles = oFolder.listFiles();
		String sFName, sExt;

		for ( int iFile = 0; iFile < sArrFiles.length; iFile++ ) {
			if ( sArrFiles[iFile].isDirectory() )
				continue;
			sFName = CTec_Utils.s_fileFileNameOf( sArrFiles[iFile].toString() );
			sExt = CTec_Utils.s_fileExtensionOf( sFName ).toLowerCase();
			
			if ( sExt.equals( SAFileSplit.sC_SAFILE_EXT ) && sFName.contains( _oArray.s_InputCrc() )  )
				iFileCount++;
		}
		return iFileCount;
	}
	
	//
	//	SetAndShowOutputFiles
	//
	static void SetAndShowOutputFiles( SuffixArray _oArray ) {
		String sCrc = _oArray.s_InputCrc();
		//
		//	Set output file(s) name, using Input unique CRC
		//
		if ( m_sOutFName.length() > 0 )
			m_sOutFullFName = CTec_Utils.s_FormFileName( m_sOutputFolder, m_sOutFName, ".txt" );
		else m_sOutFullFName = CTec_Utils.s_FormFileName( m_sOutputFolder, sC_TOPSCORES_PX + sCrc, ".txt" ); 
		
		m_sTrainCountFName = CTec_Utils.s_FormFileName( m_sOutputFolder, sC_TRAIN_COUNT_PX + sCrc, ".txt" );
		m_sTrainScoreFName = CTec_Utils.s_FormFileName( m_sOutputFolder, sC_TRAIN_SCORE_PX + sCrc, ".txt" );
		
		CTec_Utils.debugLogAndPrintLn( "top results at '" + m_sOutFullFName + "'" );
	}

	//
	//	processData: run splits of Build-Suffix-Array, compute Average, compute STD.DEV, compute Score & save Top
	//
	static void processData( SuffixArray _oArray ) {
		_oArray.prepareStats();
		m_iSplitCount = i_EnumerateSplits( _oArray );
		
		SACompute( E_ComputationType.eAverage, _oArray );
		SACompute( E_ComputationType.eStdDev, _oArray );
		SACompute( E_ComputationType.eScore, _oArray );

		if ( m_bProgress ) 
			CTec_Utils.debugLogAndPrintLn( "... Top list saved!", '=' );
		
		_oArray.b_AllDone();
	}

	//
	//	LoadAndStore: Load input data (saved as .sai) into database 
	//
	static void LoadAndStore( SuffixArray _oArray ) {
		_oArray.LoadInput( true );
		CTec_Utils.debugLogAndPrintLn( ">>> " + CTec_Utils.s_fileFileNameOf( _oArray.s_SAI$FName() ) +
				": stored lines=" + _oArray.i_FileStoredLines() + " (CRC=" + _oArray.s_InputCrc() + ")", '-' );
	}

	//
	//	main 
	//
	public static void main( String[] args ) {
		Control oControl = new Control();
		
		// Suffix Array (SA) object 
		SuffixArray oArray = new SuffixArray();
		SuffixArray.init();
		
		// Initialize Utils and MVC 
		CTec_Utils.init();
		if ( !oControl.init( args ) )
			return;
		
		CTec_Utils.setParams( m_bDebug, m_bProgress );
		//
		//	Initialize LOG and log some basic references
		//
		CTec_Utils.debugLogInit( CTec_Utils.s_filePathOf( m_sWorkFolder ), sC_PROG_NAME, true );
		CTec_Utils.debugLogAndPrintLn( ">>> Running=" + sC_PROG_NAME + " " + sC_PROG_VERS +
			" (available memory=" + CTec_Utils.s_FormatSize( CTec_Utils.u64_Memory( CTec_Utils.E_TecMEM.eMax ) ) + ")" );
		CTec_Utils.debugLogLn( "" );

		EchoParameters();
		CTec_Utils.debugLogFlush();

		oArray.SetSAParams( sC_PROG_NAME, sC_PROG_VERS, -1, m_bDebug );
		if ( !oArray.b_SetSAAnalyzeParams( m_sWorkFolder, m_iTop, m_sTestString ) ) { 
			CTec_Utils.debugLogAndPrintLn( "*** ERROR " + m_sWorkFolder + " in invalid: .sai/.saf files missing " );
			return;
		}
		
		//
		//	Load previous database or read it from file(s) and store in in memory
		//
		LoadAndStore(  oArray  );
		
		//
		//	Late settings, using Input retrieved info
		//
		SetAndShowOutputFiles( oArray );
		oArray.SetSAAnalyzeOutput( m_iMaxLines, m_iMinCount, m_sTrainCountFName, m_dMinScore, m_sTrainScoreFName );

		//
		//	Do the real work: Average, STD.DEV, Score & Top
		//
		processData( oArray );

		//
		//	Save some debug stats
		//
		LogStats( oArray );
		
		//
		//	THE END!
		//
		CTec_Utils.debugLogAndPrintLn( String.format( "!!! Total %s", CTec_Utils.s_StampTime( "run time", true ) ) );

		System.out.println("FIN");
		CTec_Utils.debugLogdone();
		return;
	}
}
