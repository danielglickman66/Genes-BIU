package pkgSAModel;

import java.util.ArrayList;

public class SAPrefix extends SASuffix {
	static public long m_i64SplitPrefixCount = 0;
	ArrayList<SASuffix> m_aloSuffixes;
	String m_sKey;

	public SAPrefix( SASuffix _oSuffix ) {
		super( _oSuffix.m_iLine, _oSuffix.m_iPos, _oSuffix.m_iLen);
		this.m_aloSuffixes = null;

		// Debug statistics
		m_i64SplitPrefixCount++;
	}

	public SAPrefix(int _iLine, int _iPos, int _iLen ) {
		super( _iLine, _iPos, _iLen);
		this.m_aloSuffixes = null;

		// Debug statistics
		m_i64SplitPrefixCount++;
	}

	public int compareTo( SAPrefix _oPrefix ) {
		return (this.m_sKey).compareTo(_oPrefix.m_sKey);
	}
}
