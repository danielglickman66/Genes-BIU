package pkgSAModel;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.util.zip.DataFormatException;
import java.util.zip.Deflater;
import java.util.zip.Inflater;

import pkgUtils.CTec_Utils;

public class SAFileCommon {

	//
	//	Handy definitions of variable size if bytes
	//
	public static final int iC_BITS_IN_BYTE = 8,
		iC_LONG_SIZE = Long.SIZE / iC_BITS_IN_BYTE,
		iC_INT_SIZE = Integer.SIZE / iC_BITS_IN_BYTE,
		iC_SHORT_SIZE = Short.SIZE / iC_BITS_IN_BYTE,
		iC_BYTE_SIZE = Byte.SIZE / iC_BITS_IN_BYTE;

	//
	//	enum E_FileType: Type of file instance
	//
	public enum E_FileType {
		eINPUT, eOUTPUT;
	}

	//
	//	enum E_ErrorCode: error codes for file/inflater/deflater operations
	//
	protected enum E_ErrorCode {
		eOK, eTYPE, eOPEN, eCLOSE, eFLUSH_HEADER, eFLUSH_BUFFER, eINVALID, eREAD, eINFLATE, eLOAD;
	}
	
	//
	//	Common header identifiers
	//
	static final protected int iC_PROGNAME_SIZE = 24, iC_DEFLATEINFLATE_BUFF_SIZE = 0x4000, iC_PROGVERS_SIZE = 8;

	//
	//	Work-on filename
	//
	public String m_sFFName = null;
	
	//
	//	Buffers min
	//
	static final protected int iC_MIN_BUFF_SIZE = 1024, iC_MAX_BUFF_SIZE = 64*1024*1024, iC_MIN_REC_COUNT = 0x4000;
	
	String m_sFileMark = null, m_sEntryMark = null;

	//	Various buffers and control variables 
	protected byte [] m_acWorkBuffer, m_acHeader, m_acDeflateInflateBuffer, m_acReadBuffer;
	protected int m_iBufferSize, m_iBuffPos, m_iDataTodo = 0;

	//	SASplit Input file control
	protected ByteArrayInputStream m_oSAInpStream;
	protected static byte [] m_acSAMemoryFile;
	
	//	SASplit Output file control
	protected ByteArrayOutputStream m_oSAOutStream;
	protected ByteArrayOutputStream m_oArrayOutStream;
	protected FileOutputStream m_oFileOutStream; 
	protected long m_i64SAFileSize;

	protected Inflater m_oInflater;
	
	//	Structure of the FILE HEADER:  
	protected int m_iPrologueSize;
	protected int m_iRecSize;
	protected int m_iFlags;
	protected int m_iRecords;
	protected byte [] m_acCrLf;
	
	//	Temporary variable for long/int/short conversion to bytes 
	protected int m_iIntBuffer = 0;

	//	Exception handling variables 
	protected String m_sErrorMsg;
	protected String m_sFilenameError;
	protected E_ErrorCode m_eErrorCode;
	
	protected E_FileType m_eFileType;

	//	SASplit number of compressed blocks in one file
	private int m_iEntryCount;
	protected int m_iOrgSize, m_iCompressedSize;

	ByteBuffer m_oRecordBuffer;
	protected int m_iBuffered;
	
	//
	//	constructor SAFileCommon 
	//
	public SAFileCommon(){
		m_oSAInpStream = null;
		m_oSAOutStream = null;
		m_oArrayOutStream = null;
		m_oFileOutStream = null; 

		m_acHeader = new byte[ iC_MIN_BUFF_SIZE ];
		m_acDeflateInflateBuffer = new byte[ iC_DEFLATEINFLATE_BUFF_SIZE ];
		
		m_oInflater = new Inflater();

		m_i64SAFileSize = 0;

		m_acWorkBuffer = null;
		m_iBuffPos = 0;
		m_iBuffered = 0;
		m_iRecSize = 0;
		m_iFlags = 0;
		
		m_iEntryCount = 0;
		
		// Fixed CR-LF pair, only for the aesthetic of HEADER
		m_acCrLf = new byte[2];
		m_acCrLf[0] = '\r';
		m_acCrLf[1] = '\n';

		m_sErrorMsg = "";
		m_eErrorCode = E_ErrorCode.eOK;
	}
	
	//
	//	b_Init
	//
	protected boolean b_Init( String _sFName, E_FileType _eFileType, int _iRecSize ) {

		m_sFFName = _sFName;
		m_iRecSize = _iRecSize;
		
		m_sFilenameError = "file '" + m_sFFName + "' operation:";
		m_iBufferSize = (int) Math.min( Math.max( iC_MIN_BUFF_SIZE, iC_MIN_REC_COUNT*m_iRecSize ), iC_MAX_BUFF_SIZE );
		m_oRecordBuffer = ByteBuffer.allocate(m_iBufferSize);

		
		//	Memory for PROLOGUE=Entry MARK+Count, Size of deflated data, Size of inflated data
		m_iPrologueSize = m_sEntryMark.length() + String.format( "%04d", 0 ).length() + iC_INT_SIZE + iC_INT_SIZE;

		m_eFileType = _eFileType;
		
		if ( m_eFileType == E_FileType.eINPUT ) {
			File oInpFile = new File( m_sFFName );
			m_acSAMemoryFile = new byte [ (int) oInpFile.length() ];
			try {
				RandomAccessFile oInpRandom = new RandomAccessFile( m_sFFName, "r" );
				oInpRandom.read( m_acSAMemoryFile );
				oInpRandom.close();
			}
			catch( Exception _soIOException ) {
				_soIOException.printStackTrace();
			}
			m_oSAInpStream = new ByteArrayInputStream( m_acSAMemoryFile );
		}
		if ( m_eFileType == E_FileType.eOUTPUT ) {
			m_oSAOutStream = new ByteArrayOutputStream();
			m_oArrayOutStream = new ByteArrayOutputStream( m_iBufferSize );
			try {
				m_oFileOutStream = new FileOutputStream( _sFName );
			}
			catch( Exception _soIOException ) {
				_soIOException.printStackTrace();
			}
		}
		
		return true;
	}
	
	//
	//	b_PutInt: Put Integer into Save buffer
	//
	public boolean b_PutInt( int _iVal ) {

		if ( m_iBuffPos + iC_INT_SIZE > m_acWorkBuffer.length ) {
			if ( !b_FlushBuffer() )
				return false;
		}

		for ( int i = 0; i < iC_INT_SIZE; ++i ) {
			m_acWorkBuffer[m_iBuffPos++] = (byte)(_iVal & 0xFF);
			_iVal >>= 8;
	    }
		return true;
	}
	
	//
	//	b_PutShort: Put Short into Save buffer
	//
	public boolean b_PutShort( short _wVal ){

		if ( m_iBuffPos + iC_SHORT_SIZE > m_acWorkBuffer.length ) {
			if ( !b_FlushBuffer() )
				return false;
		}

		for ( int i = 0; i < iC_SHORT_SIZE; ++i ) {
			m_acWorkBuffer[m_iBuffPos++] = (byte)(_wVal & 0xFF);
			_wVal >>= 8;
		}
		return true;
	}
	//
	//	b_PutShort: Put Short (passed as Integer) into Save buffer
	//
	public boolean b_PutShort( int _iVal ){
		return b_PutShort( (short) _iVal );
	}

	//
	//	b_PutString: Put String.length + String into Save buffer
	//
	public boolean b_PutString( String _sVal, int _iMaxSize ) {
		int iLen = Math.min( _sVal.length(), _iMaxSize );

		if ( m_iBuffPos + iLen + iC_SHORT_SIZE > m_acWorkBuffer.length ) {
			if ( !b_FlushBuffer() )
				return false;
		}

		if ( !b_PutShort( iLen ) )
			return false;

		System.arraycopy( _sVal.getBytes(), 0, m_acWorkBuffer, m_iBuffPos, iLen );
		m_iBuffPos += iLen;
		return true;
	}
	
	//
	//	b_PutEntry: Put in buffer a PROLOGUE identifying compressed file
	//
	public boolean b_PutEntry( int _iOrgSize, int _iCompressedSize, int _iEntry ){
		String sEntry;
		int iBuffPos = 0;

		sEntry = String.format( m_sEntryMark + "%04d", _iEntry );
		System.arraycopy( sEntry.getBytes(), 0, m_acHeader, iBuffPos, sEntry.length() );
		iBuffPos += sEntry.length();

		for ( int i = 0; i < iC_INT_SIZE; ++i ) {
			m_acHeader[iBuffPos++] = (byte)( _iOrgSize & 0xFF );
			_iOrgSize >>= 8;
		}
		for ( int i = 0; i < iC_INT_SIZE; ++i ) {
			m_acHeader[iBuffPos++] = (byte)( _iCompressedSize & 0xFF );
			_iCompressedSize >>= 8;
		}

		return true;
	}

	//
	//	b_WriteHeader: Put & Write the HEADER structure
	//
	public boolean b_WriteHeader( String _sProgName, String _sProgVers, int _iRecords ){
		int iLen;
		
		m_acWorkBuffer = new byte[ iC_MIN_BUFF_SIZE ];
		m_iRecords = _iRecords;
		m_iDataTodo = m_iRecords*m_iRecSize;

		m_iBuffPos = 0;
		System.arraycopy( m_sFileMark.getBytes(), 0, m_acWorkBuffer, m_iBuffPos, m_sFileMark.length() );
		m_iBuffPos += m_sFileMark.length();

		iLen = Math.min( _sProgName.length(), iC_PROGNAME_SIZE );
		b_PutShort( iLen );
		b_PutString( CTec_Utils.s_PadRight( _sProgName, iC_PROGNAME_SIZE ), iC_PROGNAME_SIZE );
		iLen = Math.min( _sProgVers.length(), iC_PROGNAME_SIZE );
		b_PutShort( iLen );
		b_PutString( CTec_Utils.s_PadRight( _sProgVers, iC_PROGVERS_SIZE ), iC_PROGVERS_SIZE );

		b_PutInt( m_iRecSize );
		b_PutInt( m_iRecords );

		//	Reserved
		b_PutInt( 0 );
		b_PutInt( 0 );

		b_PutShort( m_iFlags );

		System.arraycopy( m_acCrLf, 0, m_acWorkBuffer, m_iBuffPos, m_acCrLf.length );
		m_iBuffPos += m_acCrLf.length;
		
		if ( !b_FlushHeader() )
			return false;
		
		return true;
	}

	//
	//	b_FlushHeader: Write SAFile HEADER to file
	//
	public boolean b_FlushHeader() {
		m_oSAOutStream.write( m_acWorkBuffer, 0, m_iBuffPos );
		m_iBuffPos = 0;
		return true;
	}
	
	//
	//	b_FlushBuffer: Write SAFile PROLOGUE and SUFFIX compressed data block to file
	//
	public boolean b_FlushBuffer() {
		int iByteCount, iOrigSize, iCompressedSize;
		
		if ( m_oRecordBuffer.position() == 0 )
			return true;
		
		iOrigSize = m_oRecordBuffer.position();
		
		//
		// Prepare buffer
		//
		m_oArrayOutStream.reset();
		Deflater m_oDeflater = new Deflater();  
		m_oDeflater.setInput( m_oRecordBuffer.array(), 0, m_oRecordBuffer.position() );
		
		m_oDeflater.finish();  

		while ( !m_oDeflater.finished() ) {  
			iByteCount = m_oDeflater.deflate( m_acDeflateInflateBuffer );  
			m_oArrayOutStream.write( m_acDeflateInflateBuffer, 0, iByteCount );   
		}  
		try {
			//
			//	Write PROLOGUE
			//
			iCompressedSize = (int) m_oArrayOutStream.size(); 
			b_PutEntry( iOrigSize, iCompressedSize, ++m_iEntryCount );

			m_oSAOutStream.write( m_acHeader, 0, m_iPrologueSize );
			
			//
			// Write buffer
			//
			m_oSAOutStream.write( m_oArrayOutStream.toByteArray() );

		} catch (IOException e) {
			e.printStackTrace();
			return false;
		}
		
		//
		// Back to start for next buffer
		//
		m_oRecordBuffer.clear();
		m_iBuffPos = 0;
		
		m_i64SAFileSize += m_oSAOutStream.size();

		try {
			m_oSAOutStream.writeTo( m_oFileOutStream );
			m_oSAOutStream.reset();
		}
		catch ( IOException _soIOException ) {
			_soIOException.printStackTrace();
		}
		
		return true;
	}

	//
	//	b_ReadShort: Read Short from SA file
	//
	boolean b_ReadShort() {
		
		 m_oSAInpStream.read( m_acHeader, 0, iC_SHORT_SIZE );
		
		m_iIntBuffer = 0;
		for ( int i = iC_SHORT_SIZE - 1; i >= 0; --i ) {
			m_iIntBuffer = ( m_iIntBuffer << 8 ) + ( m_acHeader[i] & 0xFF );
	    }
		return true;
	}
	
	//
	//	b_ReadInt: Read Integer from SA file
	//
	boolean b_ReadInt() {

		m_oSAInpStream.read( m_acHeader, 0, iC_INT_SIZE );
			
		
		m_iIntBuffer = 0;
		for ( int i = iC_INT_SIZE - 1; i >= 0; --i ) {
			m_iIntBuffer = ( m_iIntBuffer << 8 ) + ( m_acHeader[i] & 0xFF );
	    }
		return true;
	}
	
	//
	//	b_ReadString: Read String.length then String from SA file
	//
	boolean b_ReadString() {
		if ( !b_ReadShort() )
			return false;
		m_oSAInpStream.read( m_acHeader, 0, m_iIntBuffer );
		return true;
	}
	
	//
	//	b_ReadHeader: Read HEADER of SA file
	//
	public boolean b_ReadHeader(){
		int iBufferSize;
		String sMark = null;
		byte [] acMark = new byte [ m_sFileMark.length() ];
		
		m_oSAInpStream.read( acMark, 0, m_sFileMark.length() );
			
		sMark = new String( acMark );
		if ( !sMark.equals( m_sFileMark ) ) {
			m_eErrorCode = E_ErrorCode.eINVALID;
			m_sErrorMsg = m_sFilenameError + "invalid mark";
			return false;
		}

		//	Skip PROGRAM NAME
		if ( !b_ReadShort() )
			return false;
		if ( !b_ReadString() )
			return false;

		//	Skip PROGRAM VERS
		if ( !b_ReadShort() )
			return false;
		if ( !b_ReadString() )
			return false;

		//	Retrieve Record Size
		if ( !b_ReadInt() )
			return false;
		m_iRecSize = m_iIntBuffer;

		//	Retrieve Records count
		if ( !b_ReadInt() )
			return false;
		m_iRecords = m_iIntBuffer;

		//	Skip FLAGS
		if ( !b_ReadShort() )
			return false;

		//	Skip Reserved x 2
		if ( !b_ReadInt() )
			return false;
		if ( !b_ReadInt() )
			return false;

		//	Skip CR-LF
		m_oSAInpStream.read( m_acHeader, 0, 2 );
			
		m_iDataTodo = m_iRecords*m_iRecSize; 

		//	Allocate read buffer for data read and inflating it
		
		iBufferSize = (int) Math.min( Math.max( iC_MIN_BUFF_SIZE, iC_MIN_REC_COUNT*m_iRecSize ), m_iRecords*m_iRecSize );
		m_acReadBuffer = new byte[ iBufferSize ];
		m_acWorkBuffer = new byte[ iBufferSize ];
		
		m_iBuffPos = 0;
		
		return true;
	}
	
	//
	//	b_GetEntry: Get PROLOGUE identifying compressed file
	//
	public boolean b_GetEntry(){
		int iBuffPos;

		iBuffPos = m_iPrologueSize - iC_INT_SIZE - iC_INT_SIZE;

		m_iOrgSize = 0;
		for ( int i = iC_INT_SIZE - 1; i >= 0; --i ) {
			m_iOrgSize = ( m_iOrgSize << 8 ) + (int) ( m_acReadBuffer[iBuffPos+i] & 0xFF );
		}

		iBuffPos += iC_INT_SIZE;
		m_iCompressedSize = 0;
		for ( int i = iC_INT_SIZE - 1; i >= 0; --i ) {
			m_iCompressedSize = ( m_iCompressedSize << 8 ) + (int) ( m_acReadBuffer[iBuffPos+i] & 0xFF );
		}
		
		return true;
	}
	
	//
	//	b_ReadBuffer: Read a PROLOGUE, then a buffer into work area 
	//
	boolean b_ReadBuffer() {
		int iBytesRead, iDataRead, iDataTodo, iDataTotal;
		
		//
		//	Read PROLOGUE
		//
		m_oSAInpStream.read( m_acReadBuffer, 0, m_iPrologueSize );
		b_GetEntry();
		
		iDataTotal = m_iOrgSize;
		
		//
		//	Inflate SUFFIX block in buffer
		//
		iDataRead = m_oSAInpStream.read( m_acReadBuffer, 0, m_iCompressedSize );

		if ( iDataRead != m_iCompressedSize ) {
			m_eErrorCode = E_ErrorCode.eINFLATE;
			m_sErrorMsg = m_sFilenameError + "inflate";
			return false;
		}
		
		m_oInflater.setInput( m_acReadBuffer, 0, iDataRead );
		m_oRecordBuffer.position(0);
		try {
			while ( !m_oInflater.finished() ) {
				iBytesRead = m_oInflater.inflate( m_acDeflateInflateBuffer );
				if ( iBytesRead <= 0 )
					break;
				iDataTodo = Math.min( iDataTotal, m_acDeflateInflateBuffer.length );
				m_iDataTodo -= iDataTodo;
				m_oRecordBuffer.put( m_acDeflateInflateBuffer, 0, iDataTodo );
				if ( m_iDataTodo <= 0 )
					break;
			}
			
			if ( m_oInflater.finished() ) {
				m_oInflater.reset();
			}
			
		} catch ( DataFormatException _oDataFormatException ) {
			_oDataFormatException.printStackTrace();
			m_eErrorCode = E_ErrorCode.eINFLATE;
			m_sErrorMsg = m_sFilenameError + "inflate";
			return false;
		}  
		
		m_iBuffered = m_iOrgSize;
		m_oRecordBuffer.position(0);
		return true;
	}

	//
	//	b_Done
	//
	public boolean b_Done( boolean _bSaveToFile ) {
		
		if ( m_eFileType == E_FileType.eOUTPUT ) {
			// Output last bytes in buffer
			if ( !b_FlushBuffer() )
				return false;

			m_i64SAFileSize += m_oSAOutStream.size();

			//
			//	Save compressed SASplitFile to be read by next steps (in file/memory)
			//
			if ( _bSaveToFile ) {
				try {
					if ( m_oSAOutStream.size() > 0 )
						m_oSAOutStream.writeTo( m_oFileOutStream );
					m_oSAOutStream.close();
					m_oFileOutStream.close();
				}
				catch ( IOException _oIOException ) {
					_oIOException.printStackTrace();
				}
			}
		}
		if ( m_eFileType == E_FileType.eINPUT ) {
			try {
				m_oSAInpStream.close();
			} catch (IOException e) {
				e.printStackTrace();
				m_eErrorCode = E_ErrorCode.eCLOSE;
				m_sErrorMsg = m_sFilenameError + "close";
				return false;
			}
		}
		
		return true;
	}

	//
	//	s_ErrorMsg
	//
	public String s_ErrorMsg(){
		return "*** ERROR : " + m_sErrorMsg;
	}

	//
	//	i_ErrorCode
	//
	public int i_ErrorCode(){
		return m_eErrorCode.ordinal();
	}
	
	//
	//	i_Records: Return records count (loaded from SAFile)
	//
	public int i_Records() {
		return m_iRecords;
	}

	//
	//	i64_SAFileSize: Return last save compressed file size
	//
	public long i64_SAFileSize() {
		return m_i64SAFileSize;
	}

}
