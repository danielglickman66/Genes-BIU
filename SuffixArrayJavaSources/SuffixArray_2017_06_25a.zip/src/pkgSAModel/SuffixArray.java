package pkgSAModel;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import pkgUtils.CTec_CrcTable;
import pkgUtils.CTec_Utils;

public class SuffixArray {
	public static final int iC_MAX_SUFFIX_LEN = 1024, iC_SPLIT_SHORTS = 10, iC_SPLIT_MIN_COUNT = 4*1024*1024;
	static final String sC_SAI_PX = "INPUT_";
	static final char cC_OOB_CHAR = '-';
	public static final String sC_SA_DATA_FORMAT = "%,12d   %,10.3f   %30s\n";
	static final int iC_FLUSH_LIMIT = 1000;

	
	//	iC_STD_TABLE_REF is empirical, optimize for using about 1M lines, 2GB memory
	static final int iC_HASH_DEPTH_REF = 22;
	static final byte[] acC_OOBTemplate = String.format( "%0" + iC_MAX_SUFFIX_LEN + "d", 0).replace( '0', cC_OOB_CHAR ).getBytes();

	//
	//	For line parsing & storing
	//
	static final String sC_LegalUpper = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	static final String sC_LegalLower = "0123456789abcdefghijklmnopqrstuvwxyz";
	static final byte acC_LegalLower [] = sC_LegalLower.getBytes();

	static byte [] m_caBuffer = new byte[iC_MAX_SUFFIX_LEN];
	static String m_sInputCrc = null;
	
	//
	//	class Infix
	//
	public class Infix {
		// Per infix
		public int m_iCount;
		public byte [] m_caInfix;
		
		// Per length
		int m_iTotalStringsOfLength, m_iDiffStringsOfLength;
		double m_dOccurAvg, m_dSquaresSum, m_dInversedStdDev;
		public double m_dStdScore; 

		// Helpers
		double m_dTotalStringsOfLength, m_dNormalizedInversedStdDev; 

		int m_iTopSplit;
		
		public Infix(){
			this.m_iCount = 0;
			this.m_caInfix = new byte[0];
			// STD_SCORE = (specific_suffix_count - MEAN) / STD_DEV;
			this.m_dStdScore = 0.0;
			
			// number of all strings in a given length
			this.m_iTotalStringsOfLength = 0;
			this.m_dTotalStringsOfLength = 0.0;
			// number of different strings in given length
			this.m_iDiffStringsOfLength = 0;
			// MEAN(AVG) = total_count_per_length/different_strings_count_per_length
			this.m_dOccurAvg = 0.0;
			// STD_DEV = 1/ sqrt(SUM(specific_suffix_count-MEAN)^2/ (total_count_per_length ) )
			this.m_dSquaresSum = 0.0;
			
			this.m_iTopSplit = -1;
		}
		
		public Infix( Infix _oInfix ){
			this.m_iCount = _oInfix.m_iCount;
			this.m_caInfix = new byte[_oInfix.m_caInfix.length];
			System.arraycopy( _oInfix.m_caInfix, 0, this.m_caInfix, 0, _oInfix.m_caInfix.length );
			
			this.m_dStdScore = _oInfix.m_dStdScore;
			
			this.m_iTotalStringsOfLength = _oInfix.m_iTotalStringsOfLength;
			this.m_dTotalStringsOfLength = _oInfix.m_dTotalStringsOfLength; 
			this.m_iDiffStringsOfLength = _oInfix.m_iDiffStringsOfLength;
			this.m_dOccurAvg = _oInfix.m_dOccurAvg;
			this.m_dSquaresSum = _oInfix.m_dSquaresSum;
			this.m_dInversedStdDev = _oInfix.m_dInversedStdDev;
			this.m_dNormalizedInversedStdDev = _oInfix.m_dNormalizedInversedStdDev;

			this.m_iTopSplit = _oInfix.m_iTopSplit;
		}
		
		public void reset(){
			this.m_iCount = 0;
			this.m_dStdScore = 0.0;
		}
	}
	
	 Comparator<Infix> pf_compareToCount = new Comparator<Infix>() {
	      public int compare(Infix _oInfix1, Infix _oInfix2) {
	    	  if (_oInfix1.m_iCount < _oInfix2.m_iCount)
					return -1;
				else if (_oInfix1.m_iCount > _oInfix2.m_iCount)
					return 1;
				else return 0;
	      }
	 };
	 
	 Comparator<Infix> pf_compareToScore = new Comparator<Infix>() {
		 public int compare(Infix _oInfix1, Infix _oInfix2) {
	    	  if (_oInfix1.m_dStdScore < _oInfix2.m_dStdScore)
					return -1;
				else if (_oInfix1.m_dStdScore > _oInfix2.m_dStdScore)
					return 1;
				else return 0;
	      }
	 };
	
	//
	//	Variables
	//
	static String m_sAlpha, m_sComment, m_sError;
	static byte [] m_caSuffix;
	static byte [] m_caSuffixPrev;
	static int m_iSuffixPrev, m_iFileLines, m_iPrefixHdrMaxSize, m_iSplitCount;
	static long m_u64InputCrc;

	HashMap<String, SAPrefix> m_hmPrefices = new HashMap<String, SAPrefix>();
	
	ArrayList<SAPrefix> m_alPrefices;
	ArrayList<ArrayList<Integer>> m_alPrefixHdrsSets;
	Infix[] oRunningInfix = new Infix[iC_MAX_SUFFIX_LEN];
	ArrayList<Infix> m_olTopCount, m_olTopScore;

	//	m_alSplits: the set of Splits in use  
	ArrayList<String> m_slPrefixHdrs;
	ArrayList<ByteBuffer> m_aclPrefixHdrs;
	
	//	m_oSAFileData: implements Input file(s) save as inflated 
	SAFileInput m_oSAFileInput;

	//	m_oSAFileSplit: implements Split part of Suffix.Array file(s) save as inflated 
	SAFileSplit m_oSAFileSplit;
	
	boolean m_bInfixSame;

	//
	//	For line parsing, storing, saving & loading
	//
	long m_i64IllegalCount, m_64TimeSave = 0, m_64TimeLoad = 0, m_i64TimeSt = 0;

	int m_iTopCount, m_iInfixMinLen, m_iInfixMaxLen;
	
	// Temporary node for search
	SASuffix m_oSuffix = new SASuffix();
	
	double m_dTopScore;
	Timestamp m_oTimestamp;
	boolean m_bNormalize, m_bIllegal;
	String m_sProgName, m_sProgVers;
	
	public int m_iMaxLen, m_iFileRefCount, m_iSplit, 
		m_iHashDepth, m_iMaxSuffixLen, m_iDebugCount;
	
	private int m_iTop, m_iMaxLines, m_iMinCount, m_iDbgCountPrinted, m_iDbgScorePrinted, m_iDbgCountChunk, m_iDbgScoreChunk;
	private double m_dMinScore;
	private String m_sCountFName, m_sScoreFName;
	static Writer m_oCountWriter = null, m_oScoreWriter = null;

	private boolean m_bTopCountFull, m_bTopScoreFull;
	
//	==========================================================================================
	// Debugging
	String m_sTestString;
	boolean m_bDebug, m_bTestString;
	int m_iTestLen;
	static byte [] m_caTestString;

	int m_iCurrentSplit;

	public long m_i64TotInfixCount;
	public long m_i64SplitNodes, m_i64SplitSuffixCount, m_i64SplitInfixCount;
	public long m_i64SplitMaxNodes, m_i64SplitMaxSuffixCount, m_i64SplitMaxPrefixCount, m_i64SplitMaxInfixCount;
	
	public String m_sWorkFolder;
	
	//
	//	SetSAParams
	//
	public void SetSAParams( String _sProgName, String _sProgVers, int _iMaxLen, boolean _bDebug ) {
		m_sProgName = _sProgName;
		m_sProgVers = _sProgVers;

		m_iMaxLen = _iMaxLen;

		m_bDebug = _bDebug;
	}

	//
	//	setSABuildParams
	//
	public void setSABuildParams( String _sAddFolder ) {
		if ( !_sAddFolder.isEmpty() )
			m_sWorkFolder = _sAddFolder;
	}
	
	//
	//	b_SetSAAnalyzeParams
	//
	public boolean b_SetSAAnalyzeParams( String _sWorkFolder, int _iTop, String _sTestString ) {
		String sVal;
		File oFolder = null;
		File[] sArrFiles = null;
		boolean bSaiFound, bSafFound;

		m_sWorkFolder = _sWorkFolder;
		m_iTop = _iTop;

		m_sTestString = _sTestString;
		
		//
		//	debugInit	: open Count and Score debug files
		//
		if ( m_iMaxLines > 0 ) {
			try{
				m_oCountWriter = new BufferedWriter( new OutputStreamWriter( new FileOutputStream( m_sCountFName ) ) );
			} catch (IOException e) {
				System.out.println( "***ERROR: Unable to open DEBUG.Count file '"+ m_sCountFName + "'" );
			}
			try{
				m_oScoreWriter = new BufferedWriter( new OutputStreamWriter( new FileOutputStream(m_sScoreFName) ) );
			} catch (IOException e) {
				System.out.println( "***ERROR: Unable to open DEBUG.Score file '"+ m_sScoreFName + "'" );
			}
		}
		//
		//	Check validity of input
		//
		Path path = Paths.get( m_sWorkFolder );

		if ( !Files.exists( path ) )
			return false;

		bSaiFound = false;
		bSafFound = false;
		oFolder = new File( m_sWorkFolder );
		sArrFiles = oFolder.listFiles();
		for ( int iFile = 0; iFile < sArrFiles.length; iFile++ ) {
			sVal = CTec_Utils.s_fileExtensionOf( sArrFiles[iFile].toString() ).toLowerCase();
			if ( sVal.equals( SAFileInput.sC_SAINPUT_EXT ) ) {
				bSaiFound = true;
				if ( bSafFound )
					return true;
			}
			if ( sVal.equals( SAFileSplit.sC_SAFILE_EXT ) ) {
				bSafFound = true;
				if ( bSaiFound )
					return true;
			}
		}
		return false;
	}
	
	//
	//	SetSAAnalyzeOutput
	//
	public void SetSAAnalyzeOutput( int _iMaxLines, int _iMinCount, String _sCountFName, double _dMinScore, String _sScoreFName ) {
		m_iMaxLines = _iMaxLines;
		m_iMinCount = _iMinCount;
		m_sCountFName = _sCountFName;
		m_dMinScore = _dMinScore;
		m_sScoreFName = _sScoreFName;
	}
	
	//
	//	class SuffixArray
	//
	public SuffixArray(){
		m_sWorkFolder = null;

		m_oSAFileSplit = null;
		
		m_sAlpha = "";
		m_alPrefices = new ArrayList<SAPrefix>();
		m_iInfixMinLen = 0;
		m_iInfixMaxLen = 0;
		m_slPrefixHdrs = new ArrayList<String>();
		m_aclPrefixHdrs = new ArrayList<ByteBuffer>();
		m_caSuffix = new byte[iC_MAX_SUFFIX_LEN];
		m_caSuffixPrev = new byte[iC_MAX_SUFFIX_LEN];
		m_iSuffixPrev = 0;

		m_olTopCount = new ArrayList<Infix>();
		m_iTopCount = 0;
		m_olTopScore = new ArrayList<Infix>();
		m_dTopScore = 0.0;

		m_bNormalize = false;
		
		m_u64InputCrc = -1;
		m_iFileLines = 0;
		m_iSplitCount = 0;
		m_alPrefixHdrsSets = new ArrayList<ArrayList<Integer>>();
		m_iPrefixHdrMaxSize = 0;

		m_oTimestamp = null;
		m_bDebug = false;
		m_bIllegal = false;
		
		m_bTopCountFull = false;
		m_bTopScoreFull = false;
		
		m_i64IllegalCount = 0;
		
		m_iTop = 0;
		m_iMaxLen = -1;
		m_iFileRefCount = 0;
		m_iSplit = 0;
		m_iHashDepth = 0;
		m_iMaxSuffixLen = 0;
		m_bInfixSame = false;

		m_iCurrentSplit = -1;
		
		m_sError = "";

		//	DEBUG SECTION
		m_iTestLen = 0;
		m_sTestString = "";
		m_bTestString = false;
		
		m_i64TotInfixCount = 0;
		
		m_i64SplitNodes = 0;
		m_i64SplitSuffixCount = 0;
		SAPrefix.m_i64SplitPrefixCount = 0;
		m_i64SplitInfixCount = 0;
		
		m_i64SplitMaxNodes =0;
		m_i64SplitMaxSuffixCount = 0;
		m_i64SplitMaxPrefixCount = 0;

		m_iDbgCountPrinted = 0;
		m_iDbgScorePrinted = 0;
		m_iDbgCountChunk = 0;
		m_iDbgScoreChunk = 0;
		m_iDebugCount = 0;
	}
	
	//
	//	init
	//
	static public void init(){
		SASuffix.init();
	}
	
	//
	//	clearSplit: clear all tables of previous split (leaving only accumulated stats)
	//
	public void clearSplit() {
		ArrayList<SASuffix> aloSuffixes;
		Infix oInfix;
		
		m_i64SplitNodes = 0;
		m_i64SplitSuffixCount = 0;
		SAPrefix.m_i64SplitPrefixCount = 0;
		m_i64SplitInfixCount = 0;
		
		for (int k=0; k < m_iMaxSuffixLen; k++){
			oInfix = oRunningInfix[k];
			System.arraycopy( acC_OOBTemplate, 0, oInfix.m_caInfix, 0, k+1 ); 
		}

		for ( int iPrefix = 0; iPrefix < m_alPrefices.size(); iPrefix++ ){
			aloSuffixes = m_alPrefices.get(iPrefix).m_aloSuffixes;
			aloSuffixes.clear();
		}
		
		m_alPrefices.clear();
		m_hmPrefices.clear();
	}
	
	//
	//	SuffixToBuffer
	//
	void SuffixToBuffer( SASuffix _oSuffix ){
		System.arraycopy( SASuffix.m_aclDb.get(_oSuffix.m_iLine), _oSuffix.m_iPos, m_caSuffix, 0, _oSuffix.m_iLen );
	}

	//
	//	s_SuffixAsString
	//
	String s_SuffixAsString( SASuffix _oSuffix ){
		return new String( Arrays.copyOfRange( SASuffix.m_aclDb.get(_oSuffix.m_iLine), _oSuffix.m_iPos, _oSuffix.m_iPos + _oSuffix.m_iLen ) );
	}

	//
	//	prepFile
	//
	public void prepFile() {
		byte [] caBuffer = new byte[iC_MAX_SUFFIX_LEN];
		int iDbLines, iBuffLen;
		m_iFileLines = 0;

		//
		//	Compute added CRC
		//
		iDbLines = SASuffix.m_aclDb.size();
		if ( iDbLines > 0 ) {
			for ( int iLine = 0; iLine < iDbLines; iLine++) {
				caBuffer = SASuffix.m_aclDb.get(iLine);
				for ( iBuffLen = 0; iBuffLen < caBuffer.length; iBuffLen++ )
					m_u64InputCrc = CTec_CrcTable.u64Crc32[ (int) ( m_u64InputCrc ^ (long) caBuffer[iBuffLen] ) & 0x000000FF ] ^
						( ( m_u64InputCrc >> 8 ) & 0x00FFFFFF );
			}
		}
	}
	
	//
	//	b_StoreLine
	//
	public boolean b_StoreLine( String _sLine, long _i64LinesRead, int _iFileNum, long _i64FilePos ){
		int iLineLen = _sLine.length(), iPos, iBuffLen = 0;
		byte caLine [];
		
		//	Compute max suffix length
		if ( iLineLen > m_iMaxSuffixLen)
			m_iMaxSuffixLen = iLineLen;

		//
		//	Compress Unicode to single bytes
		//
		caLine = _sLine.getBytes( StandardCharsets.UTF_8 );

		//	Check line contents validity
		for ( int iCh = 0; iCh < iLineLen; iCh++ ){
			if ( sC_LegalLower.indexOf( _sLine.charAt( iCh ) ) < 0 ) {
				iPos = sC_LegalUpper.indexOf( _sLine.charAt( iCh ) ); 
				if ( iPos < 0 ) {
					if ( !m_bIllegal ) {
						CTec_Utils.debugLogAndPrintLn( "*** ERROR: illegal character '" +
							String.format( "%04x", (int) _sLine.charAt( iCh ) ) + "'" +
							" in line=" + _sLine.substring(0, 30 ) +
							" in file=" + _iFileNum +
							" pos=" + _i64FilePos + " at=" + iCh +
							" after line=" + _i64LinesRead, ' ' );
						m_bIllegal = true;
					}
					m_i64IllegalCount++;
				}
				else
					m_caBuffer[iBuffLen] = acC_LegalLower[iPos];
			}
			else
				m_caBuffer[iBuffLen] = caLine[iCh];
			
			m_u64InputCrc = CTec_CrcTable.u64Crc32[ (int) ( m_u64InputCrc ^ (long) m_caBuffer[iBuffLen] ) & 0x000000FF ] ^
					( ( m_u64InputCrc >> 8 ) & 0x00FFFFFF );
			iBuffLen++;

			if ( m_sAlpha.indexOf( _sLine.charAt( iCh ) ) < 0 ) {
				m_sAlpha = m_sAlpha + _sLine.charAt( iCh );
			}
		}
		if ( m_i64IllegalCount > 0 ) {
			m_sError = "*** ERROR: Total illegal characters in file(s)=" + m_i64IllegalCount;
			return false;
		}

		SASuffix.m_aclDb.add( Arrays.copyOfRange( m_caBuffer, 0, iBuffLen) );
		m_iFileLines++;
		
		return true;
	}
	
	//
	//	i_FileStoredLines
	//
	public int i_FileStoredLines() {
		return m_iFileLines;
	}
	
	//
	//	i_TotalStoredLines: Size of database for split computation
	//
	public int i_TotalStoredLines(){
		return SASuffix.m_aclDb.size();
	}
	
	//
	//	u64_InputCrc
	//
	public long u64_InputCrc() {
		return m_u64InputCrc;
	}
	
	//
	//	SetPrefixMax: compute how many letters will be used for split partitions
	//
	void setPrefixMax() {
		if ( m_sAlpha.length() < iC_SPLIT_SHORTS  )
			m_iPrefixHdrMaxSize = Math.max( m_iPrefixHdrMaxSize, 3 );
		else m_iPrefixHdrMaxSize = Math.max( m_iPrefixHdrMaxSize, 2 );
	}

	//
	//	i_BuildSplitList: build a list of split chars/pairs/triple to be used in sets
	//		Returns: number of splits
	//
	public int i_BuildSplitList() {
		int iChar1, iChar2, iChar3, iAlphaLen = m_sAlpha.length();
		String sSplit, sPrefixHdr;
		int iDbSize = SASuffix.m_aclDb.size();
		int iPrefixHdrSize, iPrefixHdr, iLineLen, iSuffixStop, iPrefixHdrLimit;
		byte [] acLine, acPrefixHdr;
		long u64PrefixHdrsMax, u64PrefixHdrCount;
		long [] au64PrefixHdrsCount = null;
		
		ArrayList<Integer> alPrefixHdrsIx;
		
		CTec_Utils.m_u64PrevTime = System.currentTimeMillis();
		CTec_Utils.debugLogAndPrintLn( String.format( ">>> Build: Create a list of sets (splits) with prefix-headers" ) );

		m_slPrefixHdrs.clear();
		m_aclPrefixHdrs.clear();

		//
		//	Use combination of letters (2 or 3), depending upon alphabet, to create sets of SAPrefices that will form split
		//
		setPrefixMax();

		for ( iChar1 = 0; iChar1 < iAlphaLen; iChar1++ ) {
			//
			//	Add single chars to list
			//
			sSplit = m_sAlpha.substring( iChar1, iChar1 + 1 );
			if ( m_slPrefixHdrs.contains( sSplit ) )
				continue;
			m_slPrefixHdrs.add( sSplit );
			for ( iChar2 = 0; iChar2 < iAlphaLen; iChar2++ ) {
				//
				//	Add pairs to list
				//
				sSplit = m_sAlpha.substring( iChar1, iChar1 + 1 ) +
						m_sAlpha.substring( iChar2, iChar2 + 1 );
				if ( m_slPrefixHdrs.contains( sSplit ) )
					continue;
				m_slPrefixHdrs.add( sSplit );

				//
				//	Add triples to list (for small alphabet - to have enough for sets)
				//
				if ( m_iPrefixHdrMaxSize > 2 ) {
					for ( iChar3 = 0; iChar3 < iAlphaLen; iChar3++ ) {
						sSplit = m_sAlpha.substring( iChar1, iChar1 + 1 ) +
								m_sAlpha.substring( iChar2, iChar2 + 1 ) +
								m_sAlpha.substring( iChar3, iChar3 + 1 );
						if ( m_slPrefixHdrs.contains( sSplit ) )
							continue;
						m_slPrefixHdrs.add( sSplit );
					}
				}
			}
		}
		
		//
		//	Ensure SAPrefixes are ordered, build a parallel list of byte[] for faster search 
		//
		Collections.sort( m_slPrefixHdrs );
		iPrefixHdrSize = m_slPrefixHdrs.size();
		au64PrefixHdrsCount = new long[ iPrefixHdrSize ];
		for ( iPrefixHdr = 0; iPrefixHdr < iPrefixHdrSize; iPrefixHdr++ ) {
			au64PrefixHdrsCount[iPrefixHdr] = 0;
			sPrefixHdr = m_slPrefixHdrs.get(iPrefixHdr);
			m_aclPrefixHdrs.add( ByteBuffer.wrap( sPrefixHdr.getBytes(), 0, sPrefixHdr.length() ) );
		}
		
		//
		//	Get some stats on Prefix Headers to divide split by expected file size
		//
		iPrefixHdrLimit = m_iPrefixHdrMaxSize - 1;
		
		u64PrefixHdrsMax = 0;
		CTec_Utils.beginProgress( SASuffix.m_aclDb.size() );

		for ( int iLine = 0; iLine < iDbSize; iLine ++ ) {
			acLine = SASuffix.m_aclDb.get(iLine);
			iLineLen = acLine.length;
			iSuffixStop = iLineLen - iPrefixHdrLimit;

			CTec_Utils.showProgress();
		
			for ( int iCh = 0; iCh < iSuffixStop; iCh++ ) {
				acPrefixHdr = Arrays.copyOfRange( acLine, iCh, iCh + m_iPrefixHdrMaxSize );
				iPrefixHdr = Collections.binarySearch( m_aclPrefixHdrs, ByteBuffer.wrap( acPrefixHdr, 0, m_iPrefixHdrMaxSize ) );
				au64PrefixHdrsCount[iPrefixHdr]++;
			}
		}
		for ( iPrefixHdr = 0; iPrefixHdr < iPrefixHdrSize; iPrefixHdr++ ) {
			if ( au64PrefixHdrsCount[iPrefixHdr] > u64PrefixHdrsMax )
				u64PrefixHdrsMax = au64PrefixHdrsCount[iPrefixHdr];
		}
		if ( u64PrefixHdrsMax < iC_SPLIT_MIN_COUNT )
			u64PrefixHdrsMax = iC_SPLIT_MIN_COUNT;
		
		//
		//	Build set of Prefix headers for split of singles
		//
		alPrefixHdrsIx = new ArrayList<Integer>(); 
		for ( iPrefixHdr = 0; iPrefixHdr < iPrefixHdrSize; iPrefixHdr++ ) {
			sPrefixHdr = m_slPrefixHdrs.get( iPrefixHdr );
			if ( sPrefixHdr.length() == 1 )
				alPrefixHdrsIx.add( iPrefixHdr );
		}
		m_alPrefixHdrsSets.add( alPrefixHdrsIx );

		//
		//	Build set of Prefix headers for split of pairs
		//
		if ( m_iPrefixHdrMaxSize > 2 ) {
			alPrefixHdrsIx = new ArrayList<Integer>(); 
			for ( iPrefixHdr = 0; iPrefixHdr < iPrefixHdrSize; iPrefixHdr++ ) {
				sPrefixHdr = m_slPrefixHdrs.get( iPrefixHdr );
				if ( sPrefixHdr.length() == 2 )
					alPrefixHdrsIx.add( iPrefixHdr );
			}
			m_alPrefixHdrsSets.add( alPrefixHdrsIx );
		}

		//
		//	Build set of Prefix headers for split of pairs/triples
		//
		u64PrefixHdrCount = 0;
		alPrefixHdrsIx = new ArrayList<Integer>(); 
		for ( iPrefixHdr = 0; iPrefixHdr < iPrefixHdrSize; iPrefixHdr++ ) {
			sPrefixHdr = m_slPrefixHdrs.get( iPrefixHdr );
			if ( sPrefixHdr.length() >= m_iPrefixHdrMaxSize ) {
				alPrefixHdrsIx.add( iPrefixHdr );
				if ( ( u64PrefixHdrCount > 0 ) && ( ( u64PrefixHdrCount + au64PrefixHdrsCount[iPrefixHdr] ) > u64PrefixHdrsMax ) ) { 
					m_alPrefixHdrsSets.add( alPrefixHdrsIx );
					u64PrefixHdrCount = 0;
					alPrefixHdrsIx = new ArrayList<Integer>(); 
				}
				u64PrefixHdrCount += au64PrefixHdrsCount[iPrefixHdr];
			}
		}
		if ( alPrefixHdrsIx.size() > 0 )
			m_alPrefixHdrsSets.add( alPrefixHdrsIx );
		CTec_Utils.endProgress();
	
		CTec_Utils.s_StampTime( "created in", CTec_Utils.u64_Elapsed( false ) );
		
		return m_alPrefixHdrsSets.size();
	}
	
	//
	//	i_PrefixHdrMaxSize
	//
	public int i_PrefixHdrMaxSize() {
		return m_iPrefixHdrMaxSize;
	}
	
	//
	//	s_Aplhabet
	//
	public String s_Aplhabet() {
		return m_sAlpha;
	}
	
	//
	//	s_Error
	//
	public String s_Error() {
		return m_sError;
	}
	
	//
	//	SetInfixLimits: Set min and max limits for Infix check, depending upon Split length 
	//
	void SetInfixLimits( int _iSplit ){
		m_iCurrentSplit = _iSplit;
		if ( _iSplit < m_iPrefixHdrMaxSize ) {
			m_iInfixMinLen = 0;
			m_iInfixMaxLen = _iSplit;
		}
		else {
			m_iInfixMinLen = m_iPrefixHdrMaxSize - 1;
			m_iInfixMaxLen = Integer.MAX_VALUE;
		}
	}

	//
	//	scanTotalAndDiff (per length) 
	//
	public void scanTotalAndDiff( int _iSplit ){
		ArrayList<SASuffix> aloSuffixes;
		int	iAccuLen;
		SASuffix oSuffix;
		Infix oInfix;

		SetInfixLimits( _iSplit );

		//
		//	loop on all tables
		//
		for ( int iSuffixTable = 0; iSuffixTable < m_alPrefices.size(); iSuffixTable++ ){
			aloSuffixes = m_alPrefices.get(iSuffixTable).m_aloSuffixes;
			//
			//	loop one table
			//
			for ( int iSuffix = 0; iSuffix < aloSuffixes.size() ; iSuffix++ ){
				m_bInfixSame = true;

				// get suffix
				oSuffix = aloSuffixes.get(iSuffix);
				SuffixToBuffer( oSuffix );

				iAccuLen = Math.min( oSuffix.m_iLen, m_iInfixMaxLen );
				for ( int k = m_iInfixMinLen; k < iAccuLen; k++ ) {
							
					oInfix = oRunningInfix[k];

					// 1. add count of suffix to total count of length
					oInfix.m_iTotalStringsOfLength += oSuffix.m_iCount;
					
					//	2. compare running Infix of current length to proper Infix of suffix until !eq, then , add one global different for length and replace running
					if ( !m_bInfixSame || !ByteBuffer.wrap( m_caSuffix, 0, k+1 ).equals( ByteBuffer.wrap( oInfix.m_caInfix, 0, k+1 ) ) ) {
						m_bInfixSame = false;

						// end of infix computation
						if ( oInfix.m_caInfix[0] != '-' ) {
							oInfix.m_iDiffStringsOfLength++;
						}

						// new infix
						System.arraycopy( m_caSuffix, 0, oInfix.m_caInfix, 0, k+1 );
					}
				}
			}
		}
		
		// take into account last infixes
		iAccuLen = Math.min( m_iMaxLen, m_iMaxSuffixLen );
		for ( int k = m_iInfixMinLen; k < iAccuLen; k ++ ) {
			oInfix = oRunningInfix[k];
			
			if ( oInfix.m_caInfix[0] != '-' )
				oInfix.m_iDiffStringsOfLength++;
		}
	}
	
	//
	//	calcAvgPerLength 
	//
	public void calcAverage(){
		Infix oInfix;
		int iAccuLen;

		iAccuLen = Math.min( m_iMaxLen, m_iMaxSuffixLen );
		for ( int k = 0; k < iAccuLen; k++ ) {
			oInfix = oRunningInfix[k];
			oInfix.m_dTotalStringsOfLength = (double) oInfix.m_iTotalStringsOfLength;
			if ( oInfix.m_iDiffStringsOfLength != 0)
				oInfix.m_dOccurAvg = oInfix.m_dTotalStringsOfLength / (double) oInfix.m_iDiffStringsOfLength;
			else oInfix.m_dOccurAvg = 0.0;
		}

		//	DEBUG
		if ( !m_sTestString.isEmpty() ) {
			m_iTestLen = m_sTestString.length();
			if ( m_iTestLen < oRunningInfix.length ) {
				m_bTestString = true;
				m_caTestString = m_sTestString.getBytes();
				oInfix = oRunningInfix[m_iTestLen-1];
				CTec_Utils.debugDebugLn( "Test.string                      =" + m_sTestString );
				CTec_Utils.debugDebugLn( "Total.strings.of.length          =" + String.format( "%,12d", oInfix.m_iTotalStringsOfLength ) );
				CTec_Utils.debugDebugLn( "Total.different.strings.of.length=" + String.format( "%,12d", oInfix.m_iDiffStringsOfLength ) );
				CTec_Utils.debugDebugLn( "Average.for.strings.of.length    =" + String.format( "%,8.3f", oInfix.m_dOccurAvg ) );
			}
		}
	}
	
	//
	//	scanStdDev (per length) 
	//
	public void scanStdDev( int _iSplit ){
		ArrayList<SASuffix> aloSuffixes;
		int	iAccuLen;
		SASuffix oSuffix;
		Infix oInfix;
		double dTemp;
		
		SetInfixLimits( _iSplit );

		//
		//	loop on all tables
		//
		for ( int iSuffixTable = 0; iSuffixTable < m_alPrefices.size(); iSuffixTable++ ){
			aloSuffixes = m_alPrefices.get(iSuffixTable).m_aloSuffixes;
			//
			//	loop one table
			//
			for ( int iSuffix = 0; iSuffix < aloSuffixes.size() ; iSuffix++ ){
				m_bInfixSame = true;

				// get suffix
				oSuffix = aloSuffixes.get(iSuffix);
				SuffixToBuffer( oSuffix );

				// check all infixes of current suffix (up to its length - or max required)
				iAccuLen = Math.min( oSuffix.m_iLen, m_iInfixMaxLen );
				for ( int k = m_iInfixMinLen; k < iAccuLen; k++ ) {
					//	1. Retrieve Infix
					oInfix = oRunningInfix[k];

					//	2. compare running Infix of current length to proper Infix of suffix until !eq, then , add one global different for length and replace running
					if ( !m_bInfixSame || !ByteBuffer.wrap( m_caSuffix, 0, k+1 ).equals( ByteBuffer.wrap( oInfix.m_caInfix, 0, k+1 ) ) ) {
						m_bInfixSame = false;

						if ( oInfix.m_caInfix[0] != '-' ) {
							// SUM(specific_suffix_count-MEAN)^2
							
							dTemp = ( (double) oInfix.m_iCount ) - oInfix.m_dOccurAvg;
							oInfix.m_dSquaresSum += dTemp * dTemp;
						}

						// new infix
						System.arraycopy( m_caSuffix, 0, oInfix.m_caInfix, 0, k+1 ); 
						oInfix.m_iCount = oSuffix.m_iCount;
					}
					else{
						oInfix.m_iCount += oSuffix.m_iCount;
					}
				}
			}
		}
		
		// take into account last infixes
		iAccuLen = Math.min( m_iMaxLen, m_iMaxSuffixLen );
		for ( int k = m_iInfixMinLen; k < iAccuLen; k++ ) {
			oInfix = oRunningInfix[k];

			if ( oInfix.m_caInfix[0] != '-' ) {
				// Normalized SUM(specific_suffix_count-MEAN)^2
				dTemp = ( (double) oInfix.m_iCount ) - oInfix.m_dOccurAvg;
				oInfix.m_dSquaresSum += dTemp * dTemp;
			}
		}
	}

	//
	//	calcStdDev (per length) 
	//
	public void calcStdDev(){
		Infix oInfix;
		int iAccuLen;
		double dTemp, dDbSizeInv;
		
		dDbSizeInv = 1.0d / (double) SASuffix.m_aclDb.size();
		iAccuLen = Math.min( m_iMaxLen, m_iMaxSuffixLen );
		for ( int k = 0; k < iAccuLen; k++ ) {
			oInfix = oRunningInfix[k];
			if ( oInfix.m_iDiffStringsOfLength > 0.0 ) {
				dTemp = Math.sqrt( oInfix.m_dSquaresSum / oInfix.m_iDiffStringsOfLength );
				if ( dTemp != 0.0 ) {
					oInfix.m_dInversedStdDev = 1.0d / dTemp;
					if ( m_bNormalize )
						oInfix.m_dNormalizedInversedStdDev = oInfix.m_dInversedStdDev*dDbSizeInv;
					else oInfix.m_dNormalizedInversedStdDev = oInfix.m_dInversedStdDev;
				}
				else oInfix.m_dInversedStdDev = 0.0;
			}
			else oInfix.m_dInversedStdDev = 0.0;
		}
		
		//	DEBUG
		if ( m_bTestString) {
			oInfix = oRunningInfix[m_iTestLen-1];
			CTec_Utils.debugDebugLn( "Square.sum.of.length        =" + String.format( "%,15.3f", oInfix.m_dSquaresSum ) );
			CTec_Utils.debugDebugLn( "STD-DEV.of.length           =" + String.format( "%,15.3f", 1.0d / oInfix.m_dInversedStdDev ) );
			CTec_Utils.debugDebugLn( "Normalized.STD-DEV.of.length=" + String.format( "%,15.3f", 1.0d / oInfix.m_dNormalizedInversedStdDev ) );
		}

	}
	
	//
	//	scanStdScore 
	//
	public void scanStdScore( int _iSplit ){
		ArrayList<SASuffix> aloSuffixes;
		int	iAccuLen;
		SASuffix oSuffix;
		Infix oInfix;
		
		SetInfixLimits( _iSplit );

		//
		//	loop on all tables
		//
		for ( int iSuffixTable = 0; iSuffixTable < m_alPrefices.size(); iSuffixTable++ ){
			aloSuffixes = m_alPrefices.get(iSuffixTable).m_aloSuffixes;
			//
			//	loop one table
			//
			for ( int iSuffix = 0; iSuffix < aloSuffixes.size() ; iSuffix++ ){
				m_bInfixSame = true;

				// get suffix
				oSuffix = aloSuffixes.get(iSuffix);
				SuffixToBuffer( oSuffix );

				// check all infixes of current suffix (up to its length - or max required)
				iAccuLen = Math.min( oSuffix.m_iLen, m_iInfixMaxLen );
				for ( int k = m_iInfixMinLen; k < iAccuLen; k++ ) {
					m_i64SplitInfixCount++;

					//	1. Retrieve Infix
					oInfix = oRunningInfix[k];

					//	2. compare running Infix of current length to proper Infix of suffix until !eq, then , add one global different for length and replace running
					if ( !m_bInfixSame || !ByteBuffer.wrap( m_caSuffix, 0, k+1 ).equals( ByteBuffer.wrap( oInfix.m_caInfix, 0, k+1 ) ) ) {
						m_bInfixSame = false;

						if ( oInfix.m_caInfix[0] != '-' ) {
							oInfix.m_dStdScore = ( ( (double) oInfix.m_iCount ) - oInfix.m_dOccurAvg )*oInfix.m_dNormalizedInversedStdDev;

							//	DEBUG
							if ( m_bTestString && ( m_iTestLen == k + 1 )  ) {
								if ( ByteBuffer.wrap( m_caTestString, 0, k+1 ).equals( ByteBuffer.wrap( oInfix.m_caInfix, 0, k+1 ) ) ) { 
									CTec_Utils.debugDebugLn( "Test.string.count=" + String.format( "%,12d", oInfix.m_iCount ) );
									CTec_Utils.debugDebugLn( "Test.string.score=" + String.format( "%,12.3f", oInfix.m_dStdScore ) );
								}
							}
						
							checkAndStoreTop(oInfix);
						}

						// new infix
						System.arraycopy( m_caSuffix, 0, oInfix.m_caInfix, 0, k+1 );
						oInfix.m_iCount = oSuffix.m_iCount;
					}
					else{
						oInfix.m_iCount += oSuffix.m_iCount;
					}
				}
			}
		}
		
		// take into account last infixes
		iAccuLen = Math.min( m_iMaxLen, m_iMaxSuffixLen );
		for ( int k = m_iInfixMinLen; k < iAccuLen; k++ ) {
			oInfix = oRunningInfix[k];
			if ( oInfix.m_caInfix[0] != '-' ) {
				m_i64SplitInfixCount++;
				oInfix.m_dStdScore = ( (double) oInfix.m_iCount - oInfix.m_dOccurAvg )*oInfix.m_dNormalizedInversedStdDev;
				checkAndStoreTop(oInfix);
			}
		}

		//
		//	Accumulate debug Statistics
		//
		m_i64TotInfixCount += m_i64SplitInfixCount;
		if ( m_i64SplitInfixCount > m_i64SplitMaxInfixCount )
			m_i64SplitMaxInfixCount = m_i64SplitInfixCount; 
	}
	
	//
	//	prepareStats 
	//
	public void prepareStats(){
		Infix oInfix;
		
		for ( int k=0; k < m_iMaxSuffixLen; k++ ){
			oInfix = new Infix();
			oInfix.m_caInfix = Arrays.copyOfRange( acC_OOBTemplate, 0, k+1 ); 
			oRunningInfix[k] = oInfix;
		}
	}
	
	//
	//	resetStats 
	//
	public void resetStats(){
		Infix oInfix;
		
		for (int k=0; k < m_iMaxSuffixLen; k++){
			oInfix = oRunningInfix[k];
			oInfix.reset();
			oInfix.m_caInfix = Arrays.copyOfRange( acC_OOBTemplate, 0, k+1 ); 
		}
		
	}
	
	//
	//	i64_SaveTime
	//
	public long i64_SaveTime(){
		return m_64TimeSave;
	}
	
	//
	//	i64_SAI$FileSize
	//
	public long i64_SAI$FileSize() {
		if ( m_oSAFileInput != null )
			return m_oSAFileInput.i64_SAFileSize();
		else return 0;
	}

	//
	//	i64_LoadTime
	//
	public long i64_LoadTime() {
		return m_64TimeLoad;
	}
	
	//
	//	i64_SAF$FileSize
	//
	public long i64_SAF$FileSize() {
		if ( m_oSAFileSplit != null )
			return m_oSAFileSplit.i64_SAFileSize();
		else return 0;
	}

	//
	//	i_SAFileCount
	//
	public long i_SAFileCount() {
		if ( m_oSAFileSplit != null )
			return m_oSAFileSplit.i_SAFileCount();
		else return 0;
	}
	
	//
	//	b_SaveInput: Save the input in inflated form
	//
	public boolean b_SaveInput( String _sWorkFolder ) {
		m_sWorkFolder = _sWorkFolder;
		//
		//	Stats are always useful 
		//
		m_i64TimeSt = System.currentTimeMillis();
		
		//
		//	CRC of input is used to create an (almost) unique name for output files  
		//
		String sCrc = CTec_Utils.s_FormatCrc( m_u64InputCrc );
		int	iTotalLines = SASuffix.m_aclDb.size();
		
		//
		//	Create proper .sai file
		//
		m_oSAFileInput = new SAFileInput();
		if ( !m_oSAFileInput.b_Init( m_sWorkFolder, sC_SAI_PX + sCrc,  SAFileCommon.E_FileType.eOUTPUT ) ) {
			CTec_Utils.debugLogAndPrintLn( m_oSAFileInput.s_ErrorMsg() ); 
			return false;
		}

		CTec_Utils.beginProgress( iTotalLines );

		//
		//	Write header
		//
		if ( !m_oSAFileInput.b_WriteHeader( m_sProgName, m_sProgVers, iTotalLines ) )
			return false;

		//
		//	Write retrieval data
		//
		if ( !m_oSAFileInput.b_WriteSplitInfo( m_sAlpha, m_iMaxLen ) )
			return false;
		
		//
		//	Save lines
		//
		for ( int iLine = 0; iLine < iTotalLines; iLine ++ ) {
			if ( !m_oSAFileInput.b_PutLine( SASuffix.m_aclDb.get( iLine ) ) )
				return false;
			CTec_Utils.showProgress();
		}
		
		m_oSAFileInput.b_Done( true );
		
		CTec_Utils.endProgress();
		m_64TimeSave = CTec_Utils.u64_Elapsed( m_i64TimeSt );
		return true;
	}
	
	//
	//	LoadInput: Load the input (was saved in inflated form)
	//
	public boolean LoadInput( boolean _bBuildSplits ) {
		int	iLinesTodo, iLinesDone = 0;
		byte [] oLine;
		
		//
		//	Stats are always useful 
		//
		m_i64TimeSt = System.currentTimeMillis();
		
		//	Used to identify .sai and .saf names
		m_sInputCrc = s_WorkToCrc();

		//
		//	Open proper .sai file
		//
		m_oSAFileInput = new SAFileInput();
		if ( !m_oSAFileInput.b_Init( m_sWorkFolder, sC_SAI_PX + m_sInputCrc,  SAFileCommon.E_FileType.eINPUT ) ) {
			CTec_Utils.debugLogAndPrintLn( m_oSAFileInput.s_ErrorMsg() ); 
			return false;
		}

		//
		//	Read header
		//
		if ( !m_oSAFileInput.b_ReadHeader() )
			return false;

		//
		//	Read split info
		//
		if ( !m_oSAFileInput.b_ReadSplitInfo() )
			return false;
		
		m_sAlpha = m_oSAFileInput.s_Alpha();
		if ( _bBuildSplits ) {
			m_iMaxLen = m_oSAFileInput.i_MaxLen();
			m_iSplitCount = i_BuildSplitList();
		}
		else setPrefixMax();

		//
		//	Read lines
		//
		iLinesTodo = m_oSAFileInput.i_Records();
		while ( iLinesDone < iLinesTodo ) {
			oLine = m_oSAFileInput.o_GetLine();
			if ( oLine == null )
				break;
			
			//	Compute max suffix length, store line
			if ( oLine.length > m_iMaxSuffixLen)
				m_iMaxSuffixLen = oLine.length;
			SASuffix.m_aclDb.add( Arrays.copyOfRange( oLine, 0, m_oSAFileInput.i_ReadLineLen() ) );
			iLinesDone++;
		}
		
		m_oSAFileInput.b_Done( true );
		m_iFileLines = SASuffix.m_aclDb.size();
		
		m_64TimeSave = CTec_Utils.u64_Elapsed( m_i64TimeSt );
		return true;
	}
	
	//
	//	hashToList: Merge HASH into tables, and create an overall sorted list of all tables
	//
	public boolean hashToList( int _iSplit ){
		Iterator<Entry<String,SAPrefix>> oIter = m_hmPrefices.entrySet().iterator();
		ArrayList<SAPrefix> alShortSuffixes = new ArrayList<SAPrefix>();
		SAPrefix oPrefix, oTablePrefix;
		SASuffix oSuffix;
		int iIndex, iSuffixCount;
		String sCrc = CTec_Utils.s_FormatCrc( m_u64InputCrc );
		
		//	DEBUG
		ArrayList<SASuffix> aloSuffixes;
		int iTablesSizeMin = Integer.MAX_VALUE, iTablesSizeMax = 0, iHashSize = 0;
		long i64TablesTotSize = 0;
		double dTableAvgSize = 0.0;
		//	EO.DEBUG

		// 1. pass on long strings and add to table and sort
		while( oIter.hasNext() ) {
			iHashSize++;

			Map.Entry<String, SAPrefix> oPair = (Map.Entry<String, SAPrefix>) oIter.next();
			oPrefix = (SAPrefix) oPair.getValue();
			if ( oPrefix.m_aloSuffixes != null ) {
				m_alPrefices.add(oPrefix);
				m_i64SplitSuffixCount += oPrefix.m_aloSuffixes.size();
			}
		}
		Collections.sort(m_alPrefices);

		// 2. pass on short strings and add to temp table and then sort
		oIter = m_hmPrefices.entrySet().iterator();
		while( oIter.hasNext() ) {
			Map.Entry<String, SAPrefix> oPair = (Map.Entry<String, SAPrefix>)oIter.next();
			oPrefix = (SAPrefix) oPair.getValue();
			
			if (oPrefix.m_aloSuffixes != null)
				continue;
			alShortSuffixes.add(oPrefix);
		}
		m_i64SplitSuffixCount += alShortSuffixes.size();
		Collections.sort(alShortSuffixes);
		
		// go through temp table and add all short strings using binary search
		for ( int iSuffix = alShortSuffixes.size()-1; iSuffix >= 0; iSuffix-- ){
			oPrefix = alShortSuffixes.get(iSuffix);

			oSuffix = new SASuffix( oPrefix );
			oSuffix.m_iCount = oPrefix.m_iCount;
			
			iIndex = Collections.binarySearch(m_alPrefices, oPrefix);
			iIndex = -iIndex-1;
			
			if ( iIndex >= m_alPrefices.size() ) {
				oTablePrefix = new SAPrefix( oSuffix );
				oTablePrefix.m_sKey = s_SuffixAsString( oSuffix );
				oTablePrefix.m_aloSuffixes = new ArrayList<SASuffix>();
				oTablePrefix.m_aloSuffixes.add(oSuffix);
				m_alPrefices.add(m_alPrefices.size(), oTablePrefix);
			}
			else {
				oTablePrefix = m_alPrefices.get(iIndex);
				oTablePrefix.m_sKey = s_SuffixAsString( oSuffix );
				oTablePrefix.m_aloSuffixes.add(0, oSuffix);
			}
		}
		
		//
		//	Save Suffix Array (of split) to file
		//
		m_i64TimeSt = System.currentTimeMillis();
			
		//
		//	Open proper SPLIT file
		//
		m_oSAFileSplit = new SAFileSplit();

		if ( !m_oSAFileSplit.b_Init( m_sWorkFolder, sCrc, _iSplit, SAFileCommon.E_FileType.eOUTPUT, true ) ) {
			CTec_Utils.debugLogAndPrintLn( m_oSAFileSplit.s_ErrorMsg() ); 
			return false;
		}
			
		//
		//	Count (again) number of SUFFIX
		//
		iSuffixCount = 0;
		for ( int iPrefix = 0; iPrefix < m_alPrefices.size(); iPrefix++ ){
			aloSuffixes = m_alPrefices.get(iPrefix).m_aloSuffixes;
			iSuffixCount += aloSuffixes.size();
		}

		if ( !m_oSAFileSplit.b_WriteHeader( m_sProgName, m_sProgVers, iSuffixCount ) )
			return false;

		//
		// loop on all tables
		//
		for ( int iPrefix = 0; iPrefix < m_alPrefices.size(); iPrefix++ ){
			aloSuffixes = m_alPrefices.get(iPrefix).m_aloSuffixes;
			// loop on specific table
			for ( int iSuffix = 0; iSuffix < aloSuffixes.size(); iSuffix++ ){
				//
				// get next suffix and write it to .saf
				//
				oSuffix = aloSuffixes.get(iSuffix);
				if ( !m_oSAFileSplit.b_PutRecord( oSuffix ) )
					return false;
			}
		}
		
		if ( !m_oSAFileSplit.b_Done( true ) )
			return false;

		m_64TimeSave = CTec_Utils.u64_Elapsed( m_i64TimeSt );

		//	DEBUG
		if ( m_bDebug ) {
			for (int i = 0; i < m_alPrefices.size(); i++){
				aloSuffixes = m_alPrefices.get(i).m_aloSuffixes;
				if ( iTablesSizeMin > aloSuffixes.size() )
					iTablesSizeMin = aloSuffixes.size();
				if ( iTablesSizeMax < aloSuffixes.size() )
					iTablesSizeMax = aloSuffixes.size();
				i64TablesTotSize += aloSuffixes.size();
			}
			
			if ( m_alPrefices.size() > 0 )
				dTableAvgSize = (double) i64TablesTotSize / (double) m_alPrefices.size();
			else dTableAvgSize = 0.0;
			
			if ( iTablesSizeMin > Integer.MAX_VALUE / 2 )
				iTablesSizeMin = 0;
			CTec_Utils.debugLogLn( "Tables: Total=" + m_alPrefices.size() +
				", Min.Size=" + iTablesSizeMin +
				", Max.Size=" + iTablesSizeMax +
				", Average.Size=" + String.format( "%8.3f", dTableAvgSize ) +
				", Hash.size=" + String.format( "%,6d", iHashSize ) );
			
			//
			//	Accumulate debug Statistics
			//
			if ( m_i64SplitNodes > m_i64SplitMaxNodes )
				m_i64SplitMaxNodes = m_i64SplitNodes; 

			if ( m_i64SplitSuffixCount > m_i64SplitMaxSuffixCount )
				m_i64SplitMaxSuffixCount = m_i64SplitSuffixCount; 
			
			if ( SAPrefix.m_i64SplitPrefixCount > m_i64SplitMaxPrefixCount )
				m_i64SplitMaxPrefixCount = SAPrefix.m_i64SplitPrefixCount; 
		}
		//	EO.DEBUG
		return true;
	}
	
	//
	//	AllDone
	//
	public boolean b_AllDone(){
		m_oSAFileSplit.b_Done( true, false );
		return true;
	}

	//
	//	s_SAI$FName: Name of file for saved input
	//
	public String s_SAI$FName(){
		if ( m_oSAFileInput == null )
			return "";
		return m_oSAFileInput.m_sFFName;
	}
	
	
	//
	//	s_InputCrc: CRC (retrieved from filename)
	//
	public String s_InputCrc() {
		return m_sInputCrc;
	}
		
	//
	//	s_SAF$FName: Name of file for SA split
	//
	public String s_SAF$FName() {
		if ( m_oSAFileSplit == null )
			return "";
		return m_oSAFileSplit.s_SaveFileName();
	}
	
	//
	//	ol_TopCount
	//
	public ArrayList<Infix> ol_TopCount() {
		return m_olTopCount;
	}
	
	//
	//	ol_TopScore
	//
	public ArrayList<Infix> ol_TopScore() {
		return m_olTopScore;
	}
	
	//
	//	s_WorkToCrc: retrieve the CRC used for file naming
	//
	String s_WorkToCrc() {
		String sVal;
		String [] asParts;
		File oFolder = new File( m_sWorkFolder );
		File[] sArrFiles = oFolder.listFiles();		

		if ( sArrFiles.length > 0 ) {
			sVal = CTec_Utils.s_fileFNameOf( sArrFiles[0].toString() );
			asParts = sVal.split( "_" );
			if ( asParts.length > 1 ) {
				sVal = asParts[1];
				asParts = sVal.split( "\\." );
				return asParts[0];
			}
		}
		return "";
	}
	
	//
	//	b_LoadSuffixArray
	//
	public boolean b_LoadSuffixArray( int _iSplit ) {
		SAPrefix oPrefix;
		SASuffix oSuffix;
		int iSuffixCount = 0;
		
		//
		//	Load Suffix Array (of split) from file
		//
		m_i64TimeSt = System.currentTimeMillis();
			
		//
		//	Open proper SPLIT file
		//
		m_oSAFileSplit = new SAFileSplit();

		if ( !m_oSAFileSplit.b_Init( m_sWorkFolder, m_sInputCrc, _iSplit, SAFileCommon.E_FileType.eINPUT, true ) ) {
			CTec_Utils.debugLogAndPrintLn( m_oSAFileSplit.s_ErrorMsg() ); 
			return false;
		}
			
		if ( !m_oSAFileSplit.b_ReadHeader() ) {
			CTec_Utils.debugLogAndPrintLn( m_oSAFileSplit.s_ErrorMsg() ); 
			return false;
		}
		iSuffixCount = m_oSAFileSplit.i_Records();
		
		// generate a table of SUFFIX for this SPLIT
		oPrefix = new SAPrefix( 0, 0, 0 );
		oPrefix.m_aloSuffixes = new ArrayList<SASuffix>();
		if ( !m_oSAFileSplit.b_ReadBuffer() )
			return false;

		for (int j=0; j < iSuffixCount; j++){
			oSuffix = m_oSAFileSplit.o_ReadRecord();
			if ( oSuffix == null )
				return false;
			if ( oSuffix.m_iLen == 0 )
				oSuffix.m_iLen = Math.min( SASuffix.m_aclDb.get( oSuffix.m_iLine ).length - oSuffix.m_iPos, m_iMaxLen );
			oPrefix.m_aloSuffixes.add( oSuffix );
		}
		m_alPrefices.add( oPrefix );

		if ( !m_oSAFileSplit.b_Done( false, false ) )
			return false;

		m_64TimeLoad = CTec_Utils.u64_Elapsed( m_i64TimeSt );
		CTec_Utils.debugDebugFlush();
		
		return true;
	}
	
	//
	//	insertToTopCount 
	//
	void insertToTopCount(Infix _oInfix){
		Infix oInfix;

		int iPos = Collections.binarySearch(m_olTopCount, _oInfix, pf_compareToCount);
		
		if ( iPos < 0 )
			iPos = -iPos-1;
		
		oInfix = new Infix(_oInfix);
		oInfix.m_iTopSplit = m_iCurrentSplit;
		m_olTopCount.add( iPos, oInfix );
		
		if ( m_olTopCount.size() > m_iTop ){
			m_bTopCountFull = true;
			m_olTopCount.remove(0);
		}
	}
	
	//
	//	insertToTopScore 
	//
	void insertToTopScore(Infix _oInfix){
		Infix oInfix;

		int iPos = Collections.binarySearch(m_olTopScore, _oInfix, pf_compareToScore);
		
		if (iPos < 0)
			iPos = -iPos-1;
		
		oInfix = new Infix(_oInfix);
		oInfix.m_iTopSplit = m_iCurrentSplit;
		m_olTopScore.add( iPos, oInfix );
		
		if ( m_olTopScore.size() > m_iTop ){
			m_bTopScoreFull = true;
			m_olTopScore.remove(0);
		}
	}
	
	//
	//	PrintIoExceptionMessage 
	//
	void PrintIoExceptionMessage( String _sFName ) {
		System.out.println( "***ERROR: Unable to write to '"+ _sFName + "'" );
	}
	
	//
	//	checkAndStoreTop 
	//
	public void checkAndStoreTop(Infix _oInfix) {
		boolean bDbgCount, bDbgScore;
		String sInfixAsString = null;

		//
		//	Check Count criteria, Score criteria
		//
		if ( !m_bTopCountFull || ( _oInfix.m_iCount > m_iTopCount ) ) {
			insertToTopCount(_oInfix);
			m_iTopCount = m_olTopCount.get(0).m_iCount;
		}

		if ( !m_bTopScoreFull || ( _oInfix.m_dStdScore > m_dTopScore ) ) {
			insertToTopScore(_oInfix);
			m_dTopScore = m_olTopScore.get(0).m_dStdScore;
		}
	
		//
		//	Check debug thresholds
		//
		bDbgCount = ( m_iDbgCountPrinted < m_iMaxLines ) && ( _oInfix.m_iCount > m_iMinCount ) && ( m_oCountWriter != null );
		bDbgScore = ( m_iDbgScorePrinted < m_iMaxLines ) && ( _oInfix.m_dStdScore > m_dMinScore )  && ( m_oScoreWriter != null );
		if ( bDbgCount || bDbgScore )
			sInfixAsString = new String( _oInfix.m_caInfix );

		if ( bDbgCount ) {
			try {
				m_oCountWriter.write( String.format( sC_SA_DATA_FORMAT,
					_oInfix.m_iCount, _oInfix.m_dStdScore, CTec_Utils.s_PadRight( sInfixAsString, 64) ) );

				m_iDbgCountPrinted++;
				m_iDbgCountChunk++;
				if ( m_iDbgCountChunk > iC_FLUSH_LIMIT ) {
					m_iDbgCountChunk = 0;
					m_oCountWriter.flush();
				}
			} catch( IOException e ) {
				PrintIoExceptionMessage( m_sCountFName );
			}
		}

		if ( bDbgScore ) {
			try {
				m_oScoreWriter.write( String.format( sC_SA_DATA_FORMAT,
					_oInfix.m_iCount, _oInfix.m_dStdScore, CTec_Utils.s_PadRight( sInfixAsString, 64) ) );

				m_iDbgScorePrinted++;
				m_iDbgScoreChunk++;
				if ( m_iDbgScoreChunk > iC_FLUSH_LIMIT ) {
					m_iDbgScoreChunk = 0;
					m_oScoreWriter.flush();
				}
			} catch( IOException e ) {
				PrintIoExceptionMessage( m_sScoreFName );
			}
		}
	}
	
	//
	//	Close all flush writers 
	//
	public void DbgEpilogue() {
		if ( m_oCountWriter != null ) {
			try {
				m_oCountWriter.flush();
				m_oCountWriter.close();
			} catch( IOException e ) {
				PrintIoExceptionMessage( m_sCountFName );
			}
		}
		
		if ( m_oScoreWriter != null ) {
			try {
				m_oScoreWriter.flush();
				m_oScoreWriter.close();
			} catch( IOException e ) {
				PrintIoExceptionMessage( m_sScoreFName );
			}
		}
	}
	
	//
	//	insertSuffix: Add a new suffix to: HASH (is shorter than Hash.depth) or Table of same PREFIX (long SUFFIX only) 
	//
	void insertSuffix( String _sPrefix, int _iLine, int _iPos, int _iLen ){
		SAPrefix oPrefix;
		SASuffix oSuffix;
		int iIndex, iSuffixMax;
		
		// Look for suffix in hash
		oPrefix = m_hmPrefices.get(_sPrefix);
		
		iSuffixMax = Math.min( _iLen, m_iMaxLen );
		
		if ( oPrefix == null ){
			// Create new hash entry
			SAPrefix.m_i64SplitPrefixCount++;
			
			oPrefix = new SAPrefix( _iLine, _iPos, iSuffixMax );
			oPrefix.m_sKey = _sPrefix;

			if ( iSuffixMax < m_iHashDepth ) {
				oPrefix.m_iCount = 1;
			}
			else {
				oPrefix.m_iCount = 0;

				// Create a restricted suffix array for this prefix
				oSuffix = new SASuffix( oPrefix );
				m_i64SplitNodes++;
				oSuffix.m_iCount = 1;
					
				oPrefix.m_aloSuffixes = new ArrayList<SASuffix>();
				oPrefix.m_aloSuffixes.add( oSuffix );
			}
			
			m_hmPrefices.put(_sPrefix, oPrefix);

		}
		else{
			if ( iSuffixMax >= m_iHashDepth ){
				m_oSuffix.m_iLine = _iLine;
				m_oSuffix.m_iPos = _iPos;	
				m_oSuffix.m_iLen = iSuffixMax;	
				
				iIndex = Collections.binarySearch(oPrefix.m_aloSuffixes, m_oSuffix);
				if (iIndex >= 0){
					oSuffix = oPrefix.m_aloSuffixes.get(iIndex);
					oSuffix.m_iCount++;
				}
				else{
					iIndex = -iIndex-1;
					
					oSuffix = new SASuffix( m_oSuffix );
					m_i64SplitNodes++;
					oSuffix.m_iCount = 1;
					
					oPrefix.m_aloSuffixes.add(iIndex, oSuffix);
				}
			}
			else{
				oPrefix.m_iCount++;
			}
		}
	}
	
	//
	//	buildSuffixArray 
	//
	public boolean b_BuildSuffixArray( int _iSplit, int _iPrefixHdrSize ) {
		//	NOTE: sSplit is a string of chars, representing a selection of suffixes (see below) 
		//
		// _iSplit			:	_SplitSize < iC_SPLIT_BASE_LEN	= insert all suffixes which length equal to _SplitSize 
		//						_SplitSize >= iC_SPLIT_BASE_LEN	= insert suffixes of selected Split 
		// _iPrefixHdrSize	:	Size of current prefix header (1, 2 or iC_SPLIT_BASE_LEN = 3)

		int iDbSize = SASuffix.m_aclDb.size();
		int	iLineLen, iSuffixLen, iSuffixStop, iSetSize, iPrefixHdrLimit;
		String sPrefix;
		byte [] acLine, acPrefixHdr = null;
		boolean bPrefixHdrFit;

		//	alSplitSet: the set of chars/pairs/triple composing the current split  
		ArrayList<Integer> alPrefixHdrsIx;
		ArrayList<byte []> alPrefixHdrSet = new ArrayList<byte []>();
		
		m_oTimestamp = new Timestamp(System.currentTimeMillis());
		
		iPrefixHdrLimit = _iPrefixHdrSize - 1;

		alPrefixHdrsIx = m_alPrefixHdrsSets.get( _iSplit - 1 );
		for ( int iIx = 0; iIx < alPrefixHdrsIx.size(); iIx++ ) {
			alPrefixHdrSet.add( m_aclPrefixHdrs.get( alPrefixHdrsIx.get( iIx ) ).array() );
		}

		iSetSize = alPrefixHdrSet.size(); 
		CTec_Utils.beginProgress( iDbSize*iSetSize );
	
		m_iHashDepth = iC_HASH_DEPTH_REF  / (int) Math.round( Math.sqrt( (double) m_sAlpha.length()) );

		//
		//	Run on set of valid Prefixes for this split
		//
		for ( int iSetPrefixHdr = 0; iSetPrefixHdr < iSetSize; iSetPrefixHdr++ ) {
			acPrefixHdr = alPrefixHdrSet.get( iSetPrefixHdr );

			//
			//	Run on lines, extracting prefices starting with one of the SplitPrefix-set values, build a SA Prefix for it
			//
			for ( int iLine = 0; iLine < iDbSize; iLine ++ ) {
				acLine = SASuffix.m_aclDb.get(iLine);
				iLineLen = acLine.length;
				iSuffixStop = iLineLen - iPrefixHdrLimit;
			
				CTec_Utils.showProgress();
			
				//
				//	Check prefixes of this line
				//
				for ( int iCh = 0; iCh < iSuffixStop; iCh++ ) {
					//
					//	Check on a letter-by-letter basis (avoid dynamic building of arrays)
					//
					bPrefixHdrFit = true;
					for ( int iLetter = 0; iLetter < _iPrefixHdrSize; iLetter++ ){
						if ( acPrefixHdr[iLetter] != acLine[iCh + iLetter] ) {
							bPrefixHdrFit = false;
							break;
						}
					}
					if ( !bPrefixHdrFit )
						continue;
					
					//
					//	Single/Pair splits are handle apart (below). General uses each SAHeader to generate Suffices
					//
					if ( _iPrefixHdrSize >= m_iPrefixHdrMaxSize ) {
						iSuffixLen = iLineLen - iCh; 
						if ( iSuffixLen >= m_iHashDepth ) {
							sPrefix = new String( Arrays.copyOfRange( acLine, iCh, iCh + m_iHashDepth ) );
						}
						else {
							sPrefix = new String( Arrays.copyOfRange( acLine, iCh, iCh + iSuffixLen ) );
						}
						insertSuffix( sPrefix, iLine, iCh, iSuffixLen );
					}
					//
					// insert suffixes with (identical) length shorter than _iPrefixHdrSize
					//
					else {
						sPrefix = new String( Arrays.copyOfRange( acLine, iCh, iCh + _iPrefixHdrSize ) );
						insertSuffix( sPrefix, iLine, iCh, _iPrefixHdrSize );
					}
				}
			}
		}

		CTec_Utils.endProgress();

		return true;
	}
}
