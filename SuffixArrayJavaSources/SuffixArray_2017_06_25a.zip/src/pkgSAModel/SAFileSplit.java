package pkgSAModel;

import java.io.ByteArrayInputStream;
import java.util.ArrayList;

import pkgUtils.CTec_Utils;

//
//	SASplitFile: save/load a compressed binary file of groups of SUFFIX (a Suffix Array Split)
//
public class SAFileSplit extends SAFileCommon {
	public static final String sC_SAFILE_EXT = ".saf", sC_MARK = "BIO_";

	static final String sC_SPLIT_PX = "SPLIT_";

	private String m_sSASplitFullFilename;
	private static int m_iSplit;
	
	//	SASplit Buffers for Split save/load
	static private ArrayList<byte []> m_alSASplitFiles = new ArrayList<byte []>();

	//
	//	constructor: SASplitFile
	//
	public SAFileSplit(){
		m_sSASplitFullFilename = "";
		m_iSplit = 0;
		
		m_sFileMark = sC_MARK;
		m_sEntryMark = "BIO.";
	}
	
	//
	//	s_SaveFileName
	//
	public String s_SaveFileName() {
		return m_sSASplitFullFilename;
	}
	
	//
	//	i_SAFileCount: Return total compressed file count
	//
	public int i_SAFileCount() {
		if ( m_alSASplitFiles != null )
			return m_alSASplitFiles.size();
		else return 0;
	}

	//
	//	b_Init: Common for Input & Output
	//
	public boolean b_Init( String _sFolder, String _sCrc, int _iSplit, E_FileType _eFileType, boolean _bFromFile ){
		String sFileSx = "";
		
		m_iSplit = _iSplit;

		sFileSx = String.format( "_%03d", m_iSplit );

		m_sSASplitFullFilename = CTec_Utils.s_FormFileName( _sFolder, sC_SPLIT_PX + _sCrc + sFileSx, sC_SAFILE_EXT );

		//	64-byte HEADER=MARK (4), PROGNAME (2+2+24), PROGVERS (2+2+8), RECORD.size (4). RECORDS.Count (4), SPARE-1 (4), SPARE-2 (4), Flags (2), CR-LF 
		//-!-		sC_MARK.length() +
		//-!-		iC_SHORT_SIZE + iC_SHORT_SIZE + iC_PROGNAME_SIZE +
		//-!-		iC_SHORT_SIZE + iC_SHORT_SIZE + iC_PROGVERS_SIZE +
		//-!-		iC_INT_SIZE + iC_INT_SIZE +
		//-!-		iC_INT_SIZE + iC_INT_SIZE +
		//-!-		iC_SHORT_SIZE + m_acCrLf.length;
		
		//	Memory for SUFFIX=Count, Line + coded-Len, Pos
		m_iRecSize = iC_INT_SIZE + iC_INT_SIZE + iC_SHORT_SIZE + iC_BYTE_SIZE;
		
		if ( !b_Init( m_sSASplitFullFilename, _eFileType, m_iRecSize ) )
			return false;

		if ( m_eFileType == E_FileType.eINPUT ) {
			
			if ( !_bFromFile ) {
				if ( _iSplit >= m_alSASplitFiles.size() ) {
					m_eErrorCode = E_ErrorCode.eLOAD;
					m_sErrorMsg = m_sFilenameError + "load";
					return false;
				}
				m_oSAInpStream = new ByteArrayInputStream( m_alSASplitFiles.get( _iSplit - 1 ) );
			}
		}

		return true;
	}
	
	//
	//	b_Done
	//
	public boolean b_Done( boolean _bFinalize, boolean _bSaveToFile ){
		if ( !_bFinalize )
			super.b_Done( _bSaveToFile );		

		if ( m_eFileType == E_FileType.eINPUT ) {
			if ( _bFinalize ) {
				while ( m_alSASplitFiles.size() > 0 ){
					m_alSASplitFiles.remove(0);
				}
			}
		}
		
		return true;
	}

	//
	//	o_ReadRecord
	//
	public SASuffix o_ReadRecord(){
		int iLine, iPos, iLen, iCount;
	
		if ( m_oRecordBuffer.position() + m_iRecSize > m_iBufferSize ) {
			if ( !b_ReadBuffer() )
				return null;
		}
		
		iCount = m_oRecordBuffer.getInt();
		iLine = m_oRecordBuffer.getInt();
		iPos = m_oRecordBuffer.getShort();
		iLen = m_oRecordBuffer.get();
		
		return ( new SASuffix( iLine, iPos, iLen, iCount ) );
	}
	
	//
	//	b_PutRecord: Put a SUFFIX into Save buffer
	//
	public boolean b_PutRecord( SASuffix _oSuffix ){
		
		if ( m_oRecordBuffer.position() + m_iRecSize > m_iBufferSize ) {
			if ( !b_FlushBuffer() )
				return false;
		}
		
		m_oRecordBuffer.putInt(_oSuffix.m_iCount);
		m_oRecordBuffer.putInt(_oSuffix.m_iLine);
		m_oRecordBuffer.putShort( (short) _oSuffix.m_iPos );
		if ( _oSuffix.m_iLen < iC_BYTE_SIZE )
			m_oRecordBuffer.put( (byte) ( _oSuffix.m_iLen & 0xFF ) );
		else m_oRecordBuffer.put( (byte) 0 );
		
		return true;
	}
}
