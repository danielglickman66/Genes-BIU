package pkgSAModel;

import java.util.Arrays;

import pkgUtils.CTec_Utils;

//
//	class SAFileData: implements the specific functionality for saving input lines
//
public class SAFileInput extends SAFileCommon {

	public static final String sC_SAINPUT_EXT = ".sai";
	private static final String sC_MARK = "SAI_";

	private String m_sSAInputFullFilename = null, m_sAlpha = null;
	private int m_iBufferPos = 0, m_iMaxLen = 0;

	//
	//	constructor SAFileInput: set base class variables for this type
	//
	public SAFileInput() {
		m_sFileMark = sC_MARK;
		m_sEntryMark = sC_SAINPUT_EXT;
	}

	//
	//	b_Init: Common for Input & Output
	//
	public boolean b_Init( String _sFolder, String _sFName, E_FileType _eFileType ){
		
		m_sSAInputFullFilename = CTec_Utils.s_FormFileName( _sFolder, _sFName, sC_SAINPUT_EXT );
				
		if ( !b_Init( m_sSAInputFullFilename, _eFileType, SuffixArray.iC_MAX_SUFFIX_LEN ) )
			return false;

		return true;
	}
	
	//
	//	b_WriteSplitInfo : Save necessary retrieval info
	//
	public boolean b_WriteSplitInfo( String _sAlpha, int _iMaxLen ) {
		
		b_PutString( _sAlpha, _sAlpha.length() );
		b_PutInt( _iMaxLen );

		if ( !b_FlushHeader() )
			return false;

		return true;
	}

	//
	//	b_PutLine : Put an input line into buffer
	//
	public boolean b_PutLine( byte [] _oLine ){
		
		if ( m_oRecordBuffer.position() + iC_SHORT_SIZE + _oLine.length > m_iBufferSize ) {
			if ( !b_FlushBuffer() )
				return false;
		}
		
		m_oRecordBuffer.putShort( (short) _oLine.length );
		m_oRecordBuffer.put( _oLine );

		return true;
	}

	//
	//	b_ReadSplitInfo : Retrieve split info
	//
	public boolean b_ReadSplitInfo() {
		
		if ( !b_ReadString() )
			return false;
		m_sAlpha = new String( Arrays.copyOfRange( m_acHeader, 0, m_iIntBuffer ) );

		if ( !b_ReadInt() )
			return false;
		m_iMaxLen = m_iIntBuffer;

		return true;
	}
	
	//
	//	o_GetLine : Read an input line from saved
	//
	public byte [] o_GetLine() {

		if ( m_iBufferPos >= m_iBuffered ) {
			if ( !b_ReadBuffer() )
				return null;
			m_iBufferPos = 0;
		}
		
		m_iIntBuffer = m_oRecordBuffer.getShort();
		m_iBufferPos += iC_SHORT_SIZE;

		m_oRecordBuffer.get( m_acHeader, 0, m_iIntBuffer );
		m_iBufferPos += m_iIntBuffer;
	
		return m_acHeader;
	}
	
	//
	//	s_SAIFFNname
	//
	public String s_SAIFFNname() {
		return m_sSAInputFullFilename;
	}
	
	//
	//	s_Alpha
	//
	public String s_Alpha() {
		return m_sAlpha;
	}
	
	
	//
	//	i_MaxLen
	//
	public int i_MaxLen() {
		return m_iMaxLen;
	}

	//
	//	i_ReadLineLen
	//
	public int i_ReadLineLen() {
		return m_iIntBuffer;
	}
	
	//
	//	s_ErrorMsg
	//
	public String s_ErrorMsg() {
		return "*** ERROR : " + m_sErrorMsg;
	}
}
