package control;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

import pkgUtils.CTec_FileReader;
import pkgUtils.CTec_FileReader.CTec_FileRef;
import pkgUtils.CTec_Utils;
import pkgUtils.CTec_CmdLine;
import view.View;
import model.Model;
import pkgSAModel.SAFileInput;
import pkgSAModel.SAFileSplit;
import pkgSAModel.SuffixArray;


/*
 * java -jar G:\...\FolderOfProjectWithJar\SABuilder.jar input_folder output_folder [options]
 * java -jar G:\...\FolderOfProjectWithJar\SAAnaliser.jar work_folder output_folder [options]
 */

public class Control {
	final static String sC_PROG_NAME = "SuffixArrayBuilder", sC_PROG_VERS = "1.8", sC_PROGRAMMER = "TeC", sC_SAPrefix = "SA_";

	//	Empirical rounded values (target: a computer with 2GB memory available for Java JRE)
	//		for 1,200,000 lines of about 600 chars (using an average suffix repetition of 10):
	//			raw storage	(UCS-2 LE 1,200,000 x 600)			720 MB
	//		per SPLIT (1/20 of data):
	//			hash	( 10,000 entries of (8+12+8))			300 KB
	//			tables	( 100,000*50 entries of pointer)		 60 MB
	//			Suffix nodes (10,000,000x[16+pointer])			320 MB
	//			Compressed split (compression of 50%)			 80 MB
	//														   =======
	//							TOTAL						  1,200 MB
	//
	final static int iC_SPLIT_MIN_LINES = 0x400;
	final static String sC_EXT_TEXT = ".txt";
	
	static CTec_CmdLine m_oCmdLine;
	static int m_iMaxLen;
	static String m_sInputFolder, m_sOutputFolder, m_sWorkFolder, m_sInpFName, m_sAddFolder, m_sFileSize;
	static boolean m_bUserFName = false;
	
	static int m_iFreeParamsCount, m_iMustParamsCount;

	//	Debug helpers
	static boolean m_bDebug, m_bProgress;
	static long m_i64TotSaveTime = 0, m_i64TotBuffersSize = 0;
	
	//
	//	Control: CONSTRUCTOR
	//
	public Control(){
		m_oCmdLine =  new CTec_CmdLine();
	}

	//
	//	init: Set parameters for command-line parsing and parse it
	//
	public boolean init( String[] _CmdLineArgs ){
		//
		//	We require only Input folder to be passed. All other have their default values.
		//
		m_iFreeParamsCount = 2;
		m_iMustParamsCount = 1;
		
		if (!parseCmdLine( _CmdLineArgs )){
			return false;
		}
		
		return true;
	}
	
	//
	//	parseCmdLine: Define user parameters (with defaults) and check command-line for any selected value
	//
	public static boolean parseCmdLine(String[] _asArgs){
		boolean bDone;
		
		//	Initialize parser
		m_oCmdLine.init( m_iFreeParamsCount, m_iMustParamsCount, _asArgs);
		
		//	Retrieve free parameters (if any)
		m_sInputFolder = m_oCmdLine.s_OptFree(1);
		m_sOutputFolder = m_oCmdLine.s_OptFree(2);
		
		//	Retrieve switch options
		m_bDebug = m_oCmdLine.b_OptAppears("-debug", "debug mode", -1, false);
		m_sFileSize = m_oCmdLine.s_OptAsString("-size", "choose run files (=all|s|m|l)", -1);
		m_sInpFName = m_oCmdLine.s_OptAsCaseString("-input", "input filename", -1);
		m_sAddFolder = m_oCmdLine.s_OptAsCaseString("-add", ".sai/.saf added input folder", -1);
		m_sWorkFolder = m_oCmdLine.s_OptAsCaseString("-work", ".sai/.saf save folder", -1);
		m_iMaxLen = m_oCmdLine.i_OptAsInt("-maxlen", "set max. length of infix accounted", -1, -1 );
		m_bProgress = m_oCmdLine.b_OptAppears("-progress", "progress feedback", -1, false);
		
		bDone = m_oCmdLine.b_Done( sC_PROG_NAME, sC_PROG_VERS, sC_PROGRAMMER, "input-folder [output-folder]" );
		
		if (m_sFileSize.isEmpty())
			m_sFileSize = "A";
		else
			m_sFileSize = m_sFileSize.substring(0, 1);
		
		//	Note: Should never occur, because cmd-line checks minimum parameters
		if (m_sInputFolder.isEmpty()) {
			System.out.println( "*** ERROR: Missing input folder" );
			return false;
		}
		
		//
		//	Validate input folder
		//
		if ( !Files.exists(Paths.get(m_sInputFolder) ) ) {
			System.out.println( "*** ERROR: Invalid input folder '" + m_sInputFolder + "'" );
			return false;
		}

		//
		//	Validate output folder
		//
		if (m_sOutputFolder.isEmpty()){
			m_sOutputFolder = CTec_Utils.s_filePathOf(m_sInputFolder) + CTec_Utils.getPathSeparator()+"Output";
		}
		if (!CTec_Utils.b_MakeFolder(m_sOutputFolder)){
			System.out.println( "*** ERROR: cannot create folder '" + m_sOutputFolder + "'" );
			return false;
		}
		return bDone;
	}
	
	//
	//	EchoParameters: show selections (and defaults) on screen (and LOG)
	//
	static void EchoParameters() {
		String sPrompt;
		CTec_Utils.debugLogAndPrintLn( "Running on input folder '" + m_sInputFolder + "'" );
		sPrompt = "for parameters: " +
				" maxlen=" + m_iMaxLen;
		if ( !m_sInpFName.isEmpty() )
			sPrompt = sPrompt + " input=" + m_sInpFName;
		else sPrompt = sPrompt + " file=" + m_sFileSize;
		
		if ( !m_sAddFolder.isEmpty() )
			sPrompt = sPrompt + " add=" + m_sAddFolder;

		if ( m_bDebug )
			sPrompt = sPrompt + " mode=debug";
		CTec_Utils.debugLogAndPrintLn( sPrompt );
		CTec_Utils.debugLogAndPrintLn( String.format("%064d", 0).replace( "0", "-" ) );
	}

	//
	//	LogStats: Log some summaries stats for analysis
	//
	static void LogStats( SuffixArray _oArray ) {
		if (!m_bDebug)
			return;

		CTec_Utils.debugLogLn( String.format( "Split max. nodes  =%,15d", _oArray.m_i64SplitMaxNodes ) );
		CTec_Utils.debugLogLn( String.format( "Split max.prefixes=%,15d", _oArray.m_i64SplitMaxPrefixCount ) );
		CTec_Utils.debugLogLn( String.format( "Split max.suffixes=%,15d", _oArray.m_i64SplitMaxSuffixCount ) );
	}
	
	//
	//	b_SaveInput: Save input lines along with necessary retrieval data
	//
	static boolean b_SaveInput( SuffixArray _oArray ){
		long i64SaveTime;
		CTec_Utils.debugLogAndPrintLn( String.format( ">>> Build: Suffix Array saving Input" ) );
		
		//
		//	Save input data as .sai, and show Stats
		//
		if ( !_oArray.b_SaveInput( m_sWorkFolder) )
			return false;

		i64SaveTime = _oArray.i64_SaveTime();
		m_i64TotSaveTime += i64SaveTime;
		CTec_Utils.debugLogAndPrintLn( "... Saved [" +
			CTec_Utils.s_fileFNameOf( _oArray.s_SAI$FName() ) +
			", size=" + CTec_Utils.s_FormatSize( _oArray.i64_SAI$FileSize() ) + "], " +
			CTec_Utils.s_StampTime( "saved in", i64SaveTime ), '-' );
	
		return true;
	}
	
	//
	//	processData: run splits of Build-Suffix-Array, compute Average, compute STD.DEV, compute Score & save Top
	//
	public static void processData( SuffixArray _oArray ) {
		int iSplitTotal, iSplitThis, iPrefixHdrSize;
		String sSplitFormatted, sProgressHeader;
		long i64TimeSt, i64RefTime, i64SaveTime, i64BuildTime, i64Elapsed;
		char cSep = ( m_bProgress ) ? '-' : ' ';
		
		//
		//	Evaluate number of splits necessary
		//
		iSplitTotal = _oArray.i_BuildSplitList();
		
		CTec_Utils.i_CleanExtension( m_sWorkFolder, SAFileInput.sC_SAINPUT_EXT );
		b_SaveInput( _oArray );

		//
		//	Build Suffix-Array, and store SPLITs
		//
		if ( m_bProgress ) 
			CTec_Utils.debugLogAndPrintLn( "... Building" );
		i64TimeSt = System.currentTimeMillis();
		_oArray.prepareStats();
		CTec_Utils.i_CleanExtension( m_sWorkFolder, SAFileSplit.sC_SAFILE_EXT );

		_oArray.resetStats();
		
		//
		//	
		//
		iPrefixHdrSize = 0;
		for ( iSplitThis = 1; iSplitThis <= iSplitTotal; iSplitThis++ ) {
			if ( iPrefixHdrSize < _oArray.i_PrefixHdrMaxSize() )
				iPrefixHdrSize++;

			sSplitFormatted = String.format( "%2d", iSplitThis ) + " of " + String.format( "%2d", iSplitTotal );
			sProgressHeader = " Build: Suffix Array[" + sSplitFormatted + "]= ";

			i64RefTime = System.currentTimeMillis();
			CTec_Utils.u64_Elapsed( false );
				
			//
			//	Clean previous Split data
			//
			_oArray.clearSplit();

			//
			//	Build a new Suffix Array - and save it
			//
			if ( _oArray.b_BuildSuffixArray( iSplitThis, iPrefixHdrSize ) ){

				// hash to sorted list (create virtual large sorted table)
				_oArray.hashToList( iSplitThis );

				i64SaveTime = _oArray.i64_SaveTime();
				m_i64TotSaveTime += i64SaveTime;
				i64BuildTime = CTec_Utils.u64_Elapsed( i64RefTime ) - i64SaveTime; 
					
				CTec_Utils.debugLogAndPrintLn( String.format( ">>>" + sProgressHeader + "%s",
					CTec_Utils.s_StampTime( "built in", i64BuildTime ) ) );
				m_i64TotBuffersSize += _oArray.i64_SAF$FileSize();
				CTec_Utils.debugLogAndPrintLn( "... Saved [" +
					CTec_Utils.s_fileFNameOf( _oArray.s_SAF$FName() ) +
					", size=" + CTec_Utils.s_FormatSize( _oArray.i64_SAF$FileSize() ) +
					"], total saved=" + CTec_Utils.s_FormatSize( m_i64TotBuffersSize ) );
			}
			else {
				CTec_Utils.debugLogAndPrintLn( _oArray.s_Error() );
				return;
			}
			CTec_Utils.debugLogAndPrintLn( String.format( "... SA Build [" + String.format( "%2d", iSplitThis ) + "]: " + "%s, %s",
				CTec_Utils.s_StampTime( "computed in", false ), CTec_Utils.s_StampElapsed( "Elapsed for SA build", i64TimeSt ) ), cSep );
			CTec_Utils.debugLogFlush();
		}
		
		i64Elapsed = CTec_Utils.u64_Elapsed( i64TimeSt );
		CTec_Utils.debugLogAndPrintLn( String.format( ">>> BUILD     : %s (%s, %s) %s",
			CTec_Utils.s_StampTime( "Done in", i64Elapsed ),
			CTec_Utils.s_StampTime( "saving", m_i64TotSaveTime ),
			CTec_Utils.s_StampTime( "SA", i64Elapsed-m_i64TotSaveTime ),
			CTec_Utils.s_StampTime( "total elapsed", true ) ), '-' );
		
		CTec_Utils.debugDebugFlush();
		
		_oArray.b_AllDone();
	}

	//
	//	b_ReadAndStore : Read the file(s) and store them as lines of bytes (UTF-8 characters) in memory 
	//
	static boolean b_ReadAndStore( Model _oModel, boolean _bAllFiles, SuffixArray _oArray ) {
		File oFolder = new File( m_sInputFolder ), oInputFile = null;
		FileInputStream oInputStream = null;
		File[] sArrFiles = oFolder.listFiles();
		
		String sFileName, sExt;
		CTec_FileRef oFileRef;
		int iFile = 0, iIxSizeS = 0, iIxSizeM = 0, iIxSizeL = 0;
		long i64FileSize, i64LinesRead = 0;


		// File size measurements 
		List<CTec_Utils.PairLongInt> slFileSizeIx = new ArrayList<CTec_Utils.PairLongInt>();

		
		//
		//	Select run file(s)
		//
		if ( m_sInpFName.length() > 0 ) {
			if ( !m_sInpFName.contains( CTec_Utils.getPathSeparator() ) ) {
				sFileName = CTec_Utils.s_FormFileName( m_sInputFolder, m_sInpFName, sC_EXT_TEXT ).toLowerCase();
			}
			else 
				sFileName = m_sInpFName.toLowerCase();
			for (iFile = 0; iFile < sArrFiles.length; iFile++) {
				if ( !sArrFiles[iFile].toString().toLowerCase().equals(sFileName) )
					sArrFiles[iFile] = null;
				else if ( sArrFiles[iFile].isDirectory() ) 
					sArrFiles[iFile] = null;
				else m_bUserFName = true;
			}

			if ( !m_bUserFName ) {
				CTec_Utils.debugLogAndPrintLn( "*** ERROR: Invalid input file: '" + sFileName + "'" );
				return false;
			}
			_bAllFiles = true;
		}
		else {
			if (!_bAllFiles) {
				for (iFile = 0; iFile < sArrFiles.length; iFile++) {
					oInputFile = sArrFiles[iFile];
					sExt = CTec_Utils.s_fileExtensionOf(oInputFile.getName())
							.toLowerCase();
					if (!sExt.equals(sC_EXT_TEXT))
						continue;
					i64FileSize = oInputFile.length();
					slFileSizeIx.add(new CTec_Utils.PairLongInt(i64FileSize, iFile));
				}
				if (slFileSizeIx.size() == 0) {
					CTec_Utils.debugLogAndPrintLn("*** ERROR: No input files!");
					return false;
				}
				Collections.sort(slFileSizeIx);

				iIxSizeS = slFileSizeIx.get(0).m_iVal;
				iIxSizeM = slFileSizeIx.get(slFileSizeIx.size() / 2).m_iVal;
				iIxSizeL = slFileSizeIx.get(slFileSizeIx.size() - 1).m_iVal;
			}
		}

		//
		//	Read and store data
		//
		for ( iFile = 0; iFile < sArrFiles.length; iFile++ ) {
			if ( sArrFiles[iFile] == null )
				continue;

			if (!_bAllFiles) {
				switch(m_sFileSize){
				case "S":
					if (iIxSizeS != iFile)
						continue;
					break;
				case "M":
					if (iIxSizeM != iFile)
						continue;
					break;
				default:
					if (iIxSizeL != iFile)
						continue;
				}

				oInputFile = sArrFiles[iFile];
				if (oInputFile.isDirectory())
					continue;
			}
			else oInputFile = sArrFiles[iFile];
			sFileName = oInputFile.toString();
			CTec_Utils.debugLogAndPrintLn( "Running file '" + sFileName + "'" );
			
			try {
				oInputStream = new FileInputStream(oInputFile);
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
			
			_oArray.prepFile();
			while(true) {
				oFileRef = CTec_FileReader.o_ReadLine( oInputStream );

				if ( CTec_FileReader.m_bEof )
					break;
				
				if ( oFileRef.m_sLine.isEmpty() )
					continue;
				else{
					i64LinesRead++;
					if ( oFileRef.m_sLine.length() > SuffixArray.iC_MAX_SUFFIX_LEN ) {
						CTec_Utils.debugLogAndPrintLn( "*** ERROR: line[" + i64LinesRead + "] length (" + oFileRef.m_sLine.length() + ")" +
							"in '" + sFileName + "' exceeds program limit (" + SuffixArray.iC_MAX_SUFFIX_LEN + ")"  );
						return false;
					}
					if ( !_oArray.b_StoreLine( oFileRef.m_sLine, i64LinesRead, iFile, oFileRef.m_i64Pos ) ){
						CTec_Utils.debugLogAndPrintLn( "*** ERROR: invalid file '"+ sFileName +"'" );
						return false;
					}
				}
			}
			
			CTec_Utils.debugLogAndPrintLn( ">>> " + CTec_Utils.s_fileFileNameOf(sFileName) +
				": stored lines=" + NumberFormat.getNumberInstance(Locale.US).format( _oArray.i_FileStoredLines() ), '-' );
		}
		return true;
	}

	//
	//	b_SetWorkFolder: Create a folder for .sai/.saf based on all input CRC 
	//
	static boolean b_SetWorkFolder( SuffixArray _oArray ) {
		//
		//	Option 1: user gave its preferred folder; Option 2: program builds a unique name for work folder 
		//
		if ( m_sWorkFolder.isEmpty() ) {
			m_sWorkFolder = m_sOutputFolder + CTec_Utils.getPathSeparator() + sC_SAPrefix + CTec_Utils.s_FormatCrc(_oArray.u64_InputCrc() );
		}
		else {
			if ( !m_sWorkFolder.contains( CTec_Utils.getPathSeparator() ) ) {
				m_sWorkFolder = m_sOutputFolder + CTec_Utils.getPathSeparator() + m_sWorkFolder;
			}
		}
		
		if ( !CTec_Utils.b_MakeFolder( m_sWorkFolder ) ){
			System.out.println( "*** ERROR: cannot create folder '" + m_sWorkFolder + "'" );
			return false;
		}
		else CTec_Utils.debugLogAndPrintLn( ">>> Work folder ready=" + m_sWorkFolder );
		return true;
	}

	//
	//	main 
	//
	public static void main( String[] args ) {
		// MVC
		Control oControl = new Control();
		Model oModel = new Model();
		View oView = new View();
		
		// Suffix Array (SA) object 
		SuffixArray oArray = new SuffixArray();
		SuffixArray.init();
		
		// Initialize Utils and MVC 
		CTec_Utils.init();
		oView.init();
		if ( !oControl.init( args ) )
			return;
		
		//
		//	Setup Utila parameters
		//
		CTec_Utils.setParams( m_bDebug, m_bProgress );

		//
		//	Initialize LOG, then log some basic info
		//
		CTec_Utils.debugLogInit( CTec_Utils.s_filePathOf( m_sInputFolder ), sC_PROG_NAME, true );

		CTec_Utils.debugLogAndPrintLn( ">>> Running=" + sC_PROG_NAME + " " + sC_PROG_VERS +
			" (available memory=" + CTec_Utils.s_FormatSize( CTec_Utils.u64_Memory( CTec_Utils.E_TecMEM.eMax ) ) + ")" );
		CTec_Utils.debugLogLn( "" );

		EchoParameters();
		CTec_Utils.debugLogFlush();

		if ( m_iMaxLen <= 0 )
			m_iMaxLen = SuffixArray.iC_MAX_SUFFIX_LEN - 1;

		//
		//	Identification parameters and parameters to be passed to Analyser
		//
		oArray.SetSAParams( sC_PROG_NAME, sC_PROG_VERS, m_iMaxLen, m_bDebug );
		oArray.setSABuildParams( m_sAddFolder );
		
		if ( !m_sAddFolder.isEmpty() ) {
			oArray.LoadInput( false );
			CTec_Utils.debugLogAndPrintLn( ">>> " + CTec_Utils.s_fileFileNameOf( oArray.s_SAI$FName() ) +
					": stored add folder lines=" + oArray.i_FileStoredLines(), '-' );
		}

		//
		//	Load input file(s) and store them in memory
		//
		if ( !b_ReadAndStore( oModel, m_sFileSize.equals("A"), oArray ) )
			return;

		if ( !b_SetWorkFolder( oArray ) )
			return;
		
		CTec_Utils.debugLogAndPrintLn( ">>> Total stored lines=" + NumberFormat.getNumberInstance(Locale.US).format( oArray.i_TotalStoredLines() ) +
			" (" + String.format( "%s", CTec_Utils.s_StampTime( "storage time", false ) ) + ")", '-' );

		//
		//	Do the real work: Average, STD.DEV, Score & Top
		//
		processData( oArray );

		//
		//	Save some debug stats
		//
		LogStats( oArray );
		
		//
		//	THE END!
		//
		CTec_Utils.debugLogAndPrintLn( String.format( "!!! Total %s", CTec_Utils.s_StampTime( "run time", true ) ) );

		System.out.println("FIN");
		CTec_Utils.debugLogdone();
		return;
	}
}
