package view;

public class View {

	//
	//	init
	//
	public void init(){
		
	}


}
