package control;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import beans.Beans;
import view.View;
import model.Model;
import model.Trie;

public class Control {
	public static void main(String[] args) {
		Model oModel = new Model();
		View oView = new View();

		Trie oTrie = new Trie();
		oTrie.initArray();
		int iSortCode;
		String sWord;
		
		if (args.length < 1){
			System.out.println("*** ERROR usage : genesBIU.jar path/files_folder sorting_code(0- string, 1- length, 2- counter)");
			return;
		}
		
		if (args.length < 2)
			iSortCode = 0; // default code
		else
			iSortCode = Integer.parseInt(args[1]);
		
		if ((iSortCode > 2) || (iSortCode < 0)){
			System.out.println("*** ERROR invalid sorting code");
			return;
		}

		File oFolder = new File(args[0]);
		File[] sArrFiles = oFolder.listFiles();
		List<Beans.Entry> slEntries = new ArrayList<Beans.Entry>();

		for (int iFile = 0; iFile < sArrFiles.length; iFile++) {
			//System.out.println("Reading file " + sArrFiles[iFile].toString());
			// Fetch words and insert into Trie
			List<String> slWords = oModel.readFile(sArrFiles[iFile].toString());
			for (int iWord = 0; iWord < slWords.size(); iWord++) {
				sWord = slWords.get(iWord);
				// for debug
				// if (sWord.contains("y-you")) {
				// System.out.println("hex="+ String.format("%04x", (int)
				// sWord.charAt(1)));
				// }
				// System.out.println("word=" + sWord);
				oTrie.insert(sWord);
			}
		}
		oTrie.calcAvg();
		// traverse to collect data for std dev
		oTrie.traverse(slEntries, Trie.E_Code.eSTD_DEV);
		oTrie.calcStdDev();
		// traverse to collect data for std score
		oTrie.traverse(slEntries, Trie.E_Code.eSTD_SCORE);
		// print data
		oTrie.traverse(slEntries, Trie.E_Code.ePRINT_DATA);
		oView.printStats(slEntries, View.E_Sort.values()[iSortCode]);
	}
}
