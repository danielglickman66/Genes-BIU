package beans;

public class Beans {
	// for printing options
	public static class Entry {
		public String m_sStr;
		public int m_iLen, m_iCounter;
		public double m_dAvg, m_dDev, m_dScore;

		public Entry(String _sStr, int _iLen, int _iCounter, double _dAvg,
				double _dDev, double _dScore) {
			this.m_sStr = _sStr;
			this.m_iLen = _iLen;
			this.m_iCounter = _iCounter;
			this.m_dAvg = _dAvg;
			this.m_dDev = _dDev;
			this.m_dScore = _dScore;
		}
	}
}
