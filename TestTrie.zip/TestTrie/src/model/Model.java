package model;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;

public class Model {
	public List<String> readFile(String _sFilename) {
		// standard word separators
		String sSeps = "\\t|\\s|\\.|,|\\?|\\!|;|:|/|\\\\|\\$|\\[|\\]|\\(|\\)|=";
		// ", types of ", ... and -
		sSeps = sSeps + "\\x93|\\x94|\\x82|\\x84|\\u201c|\\u201d|\\u2026|\\u0022|\\x2d";
		List<String> slRecords = new ArrayList<String>();
		try {
			BufferedReader oReader = new BufferedReader(new FileReader(_sFilename));
			String sLine;
			while ((sLine = oReader.readLine()) != null) {
				String[] sArrParts = sLine.split(sSeps);
				for (int i=0; i< sArrParts.length; i++) {
					if (sArrParts[i].length() > 0) {
						slRecords.add(sArrParts[i].toLowerCase());
					}
				}
			}
			oReader.close();
			return slRecords;
		} catch (Exception _e) {
			System.err.format("Exception occurred trying to read '%s'.", _sFilename);
			_e.printStackTrace();
			return null;
		}
	}
}
