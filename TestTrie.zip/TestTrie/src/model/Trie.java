package model;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import beans.Beans;

public class Trie {
	public enum E_Code {
	    ePRINT_DATA, eSTD_DEV, eSTD_SCORE;
	}
	
	// for calculating statistics for each length
	private class Stat {
		int m_iTotalCount, m_iStringCount;
		double m_dOccurAvg, m_dStdDev;
		
		public Stat() {
			this.m_iTotalCount = 0;
			this.m_iStringCount = 0;
			this.m_dOccurAvg = 0.0;
			this.m_dStdDev = 0.0;
		}
	}

	private TrieNode m_oRoot;
	public Stat[] m_oArrStats;
	public int m_iMaxLength;
	
    public Trie() {
    	m_oRoot = new TrieNode();
    	// currently assuming no word is longer than 30 characters
    	m_oArrStats = new Stat[30];
    	m_iMaxLength = 0;
    }
    
    // maybe not necessary? 
    public void initArray(){
    	for (int i=0; i<m_oArrStats.length; i++)
    		m_oArrStats[i] = new Stat();
    }
 
    // Inserts a word into the trie
    public void insert(String _sWord) {
    	HashMap<Character, TrieNode> children = m_oRoot.m_hmChildren;
    	
    	// to find max word-length
    	if (_sWord.length() > m_iMaxLength)
    		m_iMaxLength = _sWord.length();
 
        for(int i=0; i<_sWord.length(); i++){
            char c = _sWord.charAt(i);
            TrieNode oTrie;
            
            // already exists
            if(children.containsKey(c)){
            	oTrie = children.get(c);
            	oTrie.m_iCounter++;
            }
            else{ // create new TrieNode
            	oTrie = new TrieNode(c, _sWord.substring(0, i+1), i+1);
                children.put(c, oTrie);
                // count *different* strings of specific length
                m_oArrStats[i].m_iStringCount++;
            }
            // count *all* strings of specific length
            m_oArrStats[i].m_iTotalCount++;
        
            children = oTrie.m_hmChildren;
            
            // set leaf node
            if(i == _sWord.length()-1)
            	oTrie.m_bIsLeaf = true;    
        }
    }
 
    // Returns if the word is in the trie
    public boolean search(String _sWord) {
        TrieNode oTrie = searchNode(_sWord);
 
        if(oTrie != null && oTrie.m_bIsLeaf) 
            return true;
        else
            return false;
    }
 
    // Returns if there is any word in the trie that starts with the given prefix.
    public boolean startsWith(String _sPrefix) {
        if(searchNode(_sPrefix) == null) 
            return false;
        else
            return true;
    }
    
    public TrieNode searchNode(String _sStr){
        Map<Character, TrieNode> children = m_oRoot.m_hmChildren; 
        TrieNode oTrie = null;
        
        for(int i=0; i<_sStr.length(); i++){
            char _cChar = _sStr.charAt(i);
            if(children.containsKey(_cChar)){
            	oTrie = children.get(_cChar);
                children = oTrie.m_hmChildren;
            }
            else
                return null;
        }
        return oTrie;
    }
    
    private void selfTraverse(List<Beans.Entry> _slEntries, TrieNode _oNode, E_Code _eCode){
    	HashMap<Character, TrieNode> oChildren = _oNode.m_hmChildren;
    	Iterator oIter = oChildren.entrySet().iterator();
    	Beans.Entry oEntry;
    	int iLen = _oNode.m_iLength;
    	
    	while (oIter.hasNext()){
    		Map.Entry pair = (Map.Entry)oIter.next();
    		selfTraverse(_slEntries, (TrieNode)pair.getValue(), _eCode);
    	}
    	
    	// do job for single node
    	// print data
    	if ((_eCode == E_Code.ePRINT_DATA) && (_oNode.m_bIsLeaf)){
    		if (_oNode.m_sStr == "o")
    			System.out.println("");
    		oEntry = new Beans.Entry(_oNode.m_sStr, _oNode.m_iLength, _oNode.m_iCounter,
    				m_oArrStats[iLen].m_dOccurAvg, m_oArrStats[iLen].m_dStdDev, _oNode.m_dStdScore);
    		_slEntries.add(oEntry);
    	}
    	// collect data in preparation for std dev
    	else if (_eCode == E_Code.eSTD_DEV){
    		m_oArrStats[iLen].m_dStdDev += Math.pow(_oNode.m_iCounter - m_oArrStats[iLen].m_dOccurAvg, 2);
    	}
    	// calculate std score
    	else if (_eCode == E_Code.eSTD_SCORE){
    		_oNode.m_dStdScore = (double) (_oNode.m_iCounter - m_oArrStats[iLen].m_dOccurAvg) / m_oArrStats[iLen].m_dStdDev;
    	}
    }
    
    // code: 0 - print data, 1 - calculate std dev, 2 - calculate std score
    public void traverse(List<Beans.Entry> _slEntries, E_Code _eCode){
    	selfTraverse(_slEntries, m_oRoot, _eCode);
    }
    
    public void calcAvg(){
    	for (int i=0; i<m_oArrStats.length; i++){
    		if (m_oArrStats[i].m_iStringCount != 0){
    			m_oArrStats[i].m_dOccurAvg = (double) m_oArrStats[i].m_iTotalCount / (double) m_oArrStats[i].m_iStringCount;
    		}
    	}
    }
    
    public void calcStdDev(){
    	for (int i=0; i<m_oArrStats.length; i++){
    		m_oArrStats[i].m_dStdDev = Math.sqrt((1/(double) m_oArrStats[i].m_iStringCount)*m_oArrStats[i].m_dStdDev);
    	}
    }
}

