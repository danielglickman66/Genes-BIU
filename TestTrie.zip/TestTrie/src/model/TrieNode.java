package model;
import java.util.HashMap;

public class TrieNode {
	HashMap<Character, TrieNode> m_hmChildren = new HashMap<Character, TrieNode>();
	char m_cInfo;
	String m_sStr;
	boolean m_bIsLeaf;
	int m_iCounter, m_iLength;
	double m_dStdScore;

    public TrieNode() {}
 
    public TrieNode(char _cInfo, String _sStr, int _iLength){
    	this.m_cInfo = _cInfo;
    	this.m_sStr = _sStr;
    	this.m_bIsLeaf = false;
    	this.m_iCounter = 1;
        this.m_iLength = _iLength;
        this.m_dStdScore = 0.0;
    }
}
